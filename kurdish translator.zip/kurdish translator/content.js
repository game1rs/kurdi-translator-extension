/* Kurdî Translate — content script.
   Walks the DOM, batches text nodes, swaps them in place. No banners, no
   overlays, no alerts: the page just silently changes language.

   Hidden elements (menus, modals, tooltips) are translated up front too, so
   they are already Kurdish the moment they appear. */
(() => {
  if (window.__krdLoaded) return;
  window.__krdLoaded = true;

  const SH = globalThis.KRD_SHARED;
  if (!SH) return;
  const DEFAULTS = SH.DEFAULTS;

  const SKIP_TAGS = new Set([
    'SCRIPT', 'STYLE', 'NOSCRIPT', 'CODE', 'PRE', 'TEXTAREA', 'INPUT', 'SELECT',
    'SVG', 'CANVAS', 'IFRAME', 'KBD', 'SAMP', 'VAR', 'OBJECT', 'EMBED',
    'VIDEO', 'AUDIO', 'MATH', 'TEMPLATE', 'TITLE'
  ]);

  // Text that only shows up on hover / focus, or for screen readers.
  const ATTRS = ['title', 'placeholder', 'aria-label', 'alt'];

  const WORDISH = /[\p{L}][\p{L}\p{M}'’\-]*/u;
  const NO_TRANSLATE =
    '[contenteditable=""],[contenteditable="true"],[translate="no"],.notranslate,[data-krd-skip]';

  const S = {
    settings: { ...DEFAULTS },
    autoOn: false,
    manual: false,
    originals: [],
    origAttrs: [],
    cache: new Map(),
    url: location.href,
    mo: null,
    pendingRoots: [],
    cacheTimer: null,
    incTimer: null,
    navTimer: null,
    originalTitle: null,
    titleDone: false,
    titleToken: null,
    suspended: false,
    gen: 0,
    engine: '',
    lastError: ''
  };

  // Single translation pipeline: everything goes in here, workers drain it.
  const Q = { items: [], promise: null, done: 0, total: 0, failures: 0 };

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  /* ---------------------------------------------------------------- */
  /* Settings + cache                                                  */
  /* ---------------------------------------------------------------- */

  async function loadSettings() {
    try {
      const o = await chrome.storage.local.get({ ktSettings: {}, ktCache: {} });
      S.settings = SH.normalizeSettings(o.ktSettings);
      S.cache = new Map(Object.entries(o.ktCache || {}).slice(-1500));
    } catch {
      /* extension context lost */
    }
    return S.settings;
  }

  function isExcluded() {
    if (!S.settings.blockList) return false;
    return SH.hostInList(location.hostname, S.settings.excluded);
  }

  // Each enabled allow rule is a hard filter; with both on, a site must pass
  // both. Switched off means the rule is ignored but the list is kept.
  function isAllowed() {
    const host = location.hostname;
    if (S.settings.tldOnly && !SH.hostInTldList(host, S.settings.allowedTlds)) return false;
    if (S.settings.siteOnly && !SH.hostInList(host, S.settings.allowed)) return false;
    return true;
  }

  function isBlocked() {
    return isExcluded() || !isAllowed();
  }

  const cacheKey = (text) => S.settings.dialect + '::' + text;

  function remember(key, value) {
    S.cache.set(key, value);
    if (S.cache.size > 2500) {
      let i = 0;
      for (const k of S.cache.keys()) {
        if (i >= 500) break;
        S.cache.delete(k);
        i += 1;
      }
    }
    scheduleCacheFlush();
  }

  function scheduleCacheFlush() {
    clearTimeout(S.cacheTimer);
    S.cacheTimer = setTimeout(flushCache, 2500);
  }

  function flushCache() {
    try {
      const obj = {};
      for (const [k, v] of [...S.cache.entries()].slice(-1500)) obj[k] = v;
      chrome.storage.local.set({ ktCache: obj }).catch(() => {});
    } catch {
      /* context lost */
    }
  }

  /* ---------------------------------------------------------------- */
  /* Collecting work                                                   */
  /* ---------------------------------------------------------------- */

  function isVisible(el, memo) {
    if (S.settings.translateHidden) return true;
    const cached = memo.get(el);
    if (cached !== undefined) return cached;
    let visible = true;
    if (typeof el.checkVisibility === 'function') {
      try {
        visible = el.checkVisibility();
      } catch {
        visible = true;
      }
    }
    memo.set(el, visible);
    return visible;
  }

  function collectItems(root) {
    const items = [];
    const scope = root && root.nodeType === 1 ? root : document.body;
    if (!scope) return items;

    const memo = new WeakMap();

    const walker = document.createTreeWalker(scope, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const v = node.nodeValue;
        if (!v || node.__krdDone) return NodeFilter.FILTER_REJECT;
        const el = node.parentElement;
        if (!el) return NodeFilter.FILTER_REJECT;
        if (SKIP_TAGS.has(el.tagName)) return NodeFilter.FILTER_REJECT;
        if (el.closest(NO_TRANSLATE)) return NodeFilter.FILTER_REJECT;
        if (v.trim().length < 2) return NodeFilter.FILTER_REJECT;
        if (!WORDISH.test(v)) return NodeFilter.FILTER_REJECT;
        if (!isVisible(el, memo)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });

    let n;
    while ((n = walker.nextNode())) {
      if (n.__krdPending) continue;
      items.push({ kind: 'text', node: n, text: n.nodeValue });
    }

    if (S.settings.translateAttributes) {
      let els;
      try {
        els = scope.querySelectorAll('[title],[placeholder],[aria-label],[alt]');
      } catch {
        els = [];
      }
      for (const el of els) {
        if (el.closest(NO_TRANSLATE)) continue;
        for (const name of ATTRS) {
          const raw = el.getAttribute(name);
          if (!raw || raw.length < 2 || !WORDISH.test(raw)) continue;
          if (el.__krdAttrsDone && el.__krdAttrsDone.has(name)) continue;
          if (!isVisible(el, memo)) continue;
          items.push({ kind: 'attr', el, name, text: raw });
        }
      }
    }

    return items;
  }

  function queueTextNode(node) {
    if (!node || node.__krdDone || node.__krdPending) return;
    const parent = node.parentElement;
    if (parent && parent.tagName === 'TITLE') return;
    const v = node.nodeValue;
    if (!v || v.trim().length < 2 || !WORDISH.test(v)) return;
    node.__krdPending = true;
    Q.items.push({ kind: 'text', node, text: v });
  }

  /* ---------------------------------------------------------------- */
  /* Applying results                                                  */
  /* ---------------------------------------------------------------- */

  function preserveSpace(orig, tr) {
    const lead = (orig.match(/^\s+/) || [''])[0];
    const trail = (orig.match(/\s+$/) || [''])[0];
    return lead + tr.replace(/^\s+|\s+$/g, '') + trail;
  }

  function applyBatch(batch, translations) {
    for (let i = 0; i < batch.length; i += 1) {
      const item = batch[i];
      const original = item.text;
      const tr = translations[i];

      if (item.kind === 'text') {
        const node = item.node;
        node.__krdPending = false;
        node.__krdDone = true;
        if (!node.isConnected) continue;
        if (typeof tr !== 'string' || !tr.trim() || tr.trim() === original.trim()) continue;
        S.originals.push({ node, text: original });
        try {
          node.nodeValue = preserveSpace(original, tr);
        } catch {
          /* node gone */
        }
      } else {
        const el = item.el;
        if (!el || !el.isConnected) continue;
        if (!el.__krdAttrsDone) el.__krdAttrsDone = new Set();
        el.__krdAttrsDone.add(item.name);
        if (typeof tr !== 'string' || !tr.trim() || tr.trim() === original.trim()) continue;
        S.origAttrs.push({ el, name: item.name, text: original });
        try {
          el.setAttribute(item.name, tr.trim());
        } catch {
          /* element gone */
        }
      }
    }
  }

  /* ---------------------------------------------------------------- */
  /* Talking to the service worker                                     */
  /* ---------------------------------------------------------------- */

  async function ask(payload, attempt = 0) {
    try {
      return await chrome.runtime.sendMessage(payload);
    } catch {
      // The service worker may be waking up — give it a couple of chances.
      if (attempt < 2) {
        await sleep(150 * (attempt + 1));
        return ask(payload, attempt + 1);
      }
      throw new Error('Extension connection lost — reload the page.');
    }
  }

  async function translateChunk(batch) {
    const gen = S.gen;
    const out = new Array(batch.length);
    const miss = [];

    for (let i = 0; i < batch.length; i += 1) {
      const k = cacheKey(batch[i].text);
      if (S.cache.has(k)) out[i] = S.cache.get(k);
      else miss.push(i);
    }

    if (miss.length) {
      const res = await ask({
        type: 'krd:translate',
        items: miss.map((i) => batch[i].text),
        dialect: S.settings.dialect,
        engine: S.settings.engine,
        model: S.settings.model
      });

      if (!res || !res.ok) throw new Error((res && res.error) || 'Translation failed.');
      if (res.engine) S.engine = res.engine;

      const arr = res.translations || [];
      for (let j = 0; j < miss.length; j += 1) {
        const idx = miss[j];
        const t = arr[j];
        if (typeof t === 'string' && t.trim()) {
          out[idx] = t;
          remember(cacheKey(batch[idx].text), t);
        } else {
          out[idx] = batch[idx].text;
        }
      }
    }

    if (S.gen !== gen) return; // restored or reset while this was in flight
    applyBatch(batch, out);
    Q.done += batch.length;
    badge(String(Q.done));
  }

  /* ---------------------------------------------------------------- */
  /* Pipeline                                                          */
  /* ---------------------------------------------------------------- */

  function takeBatch() {
    const maxChars = Math.max(200, Number(S.settings.maxChars) || 900);
    const maxItems = Math.max(1, Number(S.settings.maxItems) || 14);
    const batch = [];
    let chars = 0;

    while (Q.items.length && batch.length < maxItems) {
      const next = Q.items[0];
      if (batch.length && chars + next.text.length > maxChars) break;
      batch.push(Q.items.shift());
      chars += next.text.length;
    }
    return batch;
  }

  async function drainLoop() {
    const concurrency = Math.max(1, Math.min(10, Number(S.settings.concurrency) || 8));

    const worker = async () => {
      for (;;) {
        const batch = takeBatch();
        if (!batch.length) return;
        try {
          await translateChunk(batch);
        } catch (e) {
          Q.failures += 1;
          S.lastError = String((e && e.message) || e);
          for (const item of batch) {
            if (item.kind === 'text') item.node.__krdPending = false;
          }
        }
      }
    };

    await Promise.all(Array.from({ length: concurrency }, worker));
  }

  // Start the workers if there is work and nobody is working.
  function kick() {
    if (Q.promise || !Q.items.length) return Q.promise || Promise.resolve();

    Q.promise = (async () => {
      try {
        await drainLoop();
      } finally {
        Q.promise = null;
        if (!Q.items.length) badge(Q.failures ? '!' : '');
        // Items can arrive in the gap between the loop ending and this line.
        else kick();
      }
    })();
    return Q.promise;
  }

  function enqueue(items) {
    if (items && items.length) {
      for (const it of items) {
        if (it.kind === 'text') {
          if (it.node.__krdDone || it.node.__krdPending) continue;
          it.node.__krdPending = true;
        }
        Q.items.push(it);
      }
      Q.total += items.length;
    }
    return kick();
  }

  /* ---------------------------------------------------------------- */
  /* Full page pass                                                    */
  /* ---------------------------------------------------------------- */

  function badge(text) {
    try {
      chrome.runtime.sendMessage({ type: 'krd:badge', text }).catch(() => {});
    } catch {
      /* ignore */
    }
  }

  function startPass({ force = false } = {}) {
    if (!force && isBlocked()) return Promise.resolve();
    S.suspended = false;
    if (!S.settings.apiKey && S.settings.engine === 'groq') {
      S.lastError = 'Groq-only mode needs an API key.';
      badge('!');
      return Promise.resolve();
    }

    // The title goes out in parallel with the body, never after it.
    translateTitle();

    const cap = Math.max(2000, Number(S.settings.maxCharsPerPass) || 90000);
    const all = collectItems(document.body);
    let total = 0;
    const capped = [];
    for (const it of all) {
      if (total + it.text.length > cap) break;
      total += it.text.length;
      capped.push(it);
    }
    return enqueue(capped);
  }

  function translateTitle() {
    if (!S.settings.translateTitle || S.titleDone) return;
    const title = document.title;
    if (!title || title.trim().length < 2) return;
    S.titleDone = true;
    S.originalTitle = title;
    const token = {};
    S.titleToken = token;

    ask({
      type: 'krd:translate',
      items: [title],
      dialect: S.settings.dialect,
      engine: S.settings.engine,
      model: S.settings.model
    })
      .then((res) => {
        if (S.titleToken !== token) return; // restored or superseded meanwhile
        if (document.title !== title) return; // the page changed its own title
        if (res && res.ok && res.translations && res.translations[0]) {
          document.title = res.translations[0];
        }
      })
      .catch(() => {});
  }

  /* ---------------------------------------------------------------- */
  /* Restore                                                           */
  /* ---------------------------------------------------------------- */

  function restore() {
    S.suspended = true;
    S.gen += 1; // ignore batches that are still in flight
    for (const it of Q.items) {
      if (it.kind === 'text') it.node.__krdPending = false;
    }
    Q.items.length = 0;

    for (let i = S.originals.length - 1; i >= 0; i -= 1) {
      const rec = S.originals[i];
      if (!rec || !rec.node) continue;
      try {
        rec.node.nodeValue = rec.text;
        rec.node.__krdDone = false;
        rec.node.__krdPending = false;
      } catch {
        /* node gone */
      }
    }
    S.originals = [];

    for (let i = S.origAttrs.length - 1; i >= 0; i -= 1) {
      const rec = S.origAttrs[i];
      if (!rec || !rec.el) continue;
      try {
        rec.el.setAttribute(rec.name, rec.text);
        if (rec.el.__krdAttrsDone) rec.el.__krdAttrsDone.delete(rec.name);
      } catch {
        /* element gone */
      }
    }
    S.origAttrs = [];

    if (S.originalTitle) {
      try {
        document.title = S.originalTitle;
      } catch {
        /* ignore */
      }
    }
    S.titleDone = false;
    S.originalTitle = null;
    S.titleToken = null;
    badge('');
  }

  /* ---------------------------------------------------------------- */
  /* Watching for new content (infinite scroll, SPA re-renders)        */
  /* ---------------------------------------------------------------- */

  // Restoring means "give me the original" — stay hands-off until the next
  // explicit action, otherwise the observer would translate it straight back.
  const shouldReact = () => !S.suspended && (S.autoOn || S.manual);

  function scheduleMutationFlush() {
    clearTimeout(S.incTimer);
    S.incTimer = setTimeout(flushMutations, 300);
  }

  function flushMutations() {
    if (!shouldReact()) return;
    const roots = S.pendingRoots;
    S.pendingRoots = [];
    for (const root of roots) {
      if (root && root.isConnected) Q.items.push(...collectItems(root));
    }
    // Text nodes queued one by one also live in Q.items, so always kick.
    kick();
  }

  function startObserver() {
    if (S.mo) S.mo.disconnect();
    S.pendingRoots = [];

    S.mo = new MutationObserver((records) => {
      if (!shouldReact()) return;

      for (const r of records) {
        if (r.type === 'characterData') {
          queueTextNode(r.target);
          scheduleMutationFlush();
        } else if (r.type === 'childList') {
          for (const n of r.addedNodes) {
            if (n.nodeType === 1) {
              S.pendingRoots.push(n);
              scheduleMutationFlush();
            } else if (n.nodeType === 3) {
              queueTextNode(n);
              scheduleMutationFlush();
            }
          }
        } else if (r.type === 'attributes') {
          // Only watched when hidden content is skipped: a class/style change
          // can reveal text that was passed over earlier.
          if (r.target && r.target.nodeType === 1) {
            S.pendingRoots.push(r.target);
            scheduleMutationFlush();
          }
        }
      }
    });

    const options = { childList: true, subtree: true, characterData: true };
    if (!S.settings.translateHidden) {
      options.attributes = true;
      options.attributeFilter = ['class', 'style', 'hidden', 'aria-hidden'];
    }
    S.mo.observe(document.documentElement, options);
  }

  /* ---------------------------------------------------------------- */
  /* URL / history watching                                            */
  /* ---------------------------------------------------------------- */

  function checkUrl() {
    if (location.href === S.url) return;
    S.url = location.href;

    if (!S.settings.translateOnNav) return;
    if (!shouldReact()) return;
    if (isBlocked()) return;

    clearTimeout(S.navTimer);
    S.navTimer = setTimeout(() => {
      // A new view usually replaces the old one; drop stale references.
      S.originals = S.originals.filter((r) => r.node && r.node.isConnected);
      S.origAttrs = S.origAttrs.filter((r) => r.el && r.el.isConnected);
      startPass();
    }, 500);
  }

  function startUrlWatcher() {
    setInterval(checkUrl, 1000);
    window.addEventListener('popstate', checkUrl);
    window.addEventListener('hashchange', checkUrl);
  }

  /* ---------------------------------------------------------------- */
  /* Status                                                            */
  /* ---------------------------------------------------------------- */

  function status() {
    return {
      url: location.href,
      auto: S.autoOn,
      manual: S.manual,
      busy: !!Q.promise,
      queued: Q.items.length,
      translated: S.originals.length + S.origAttrs.length,
      dialect: S.settings.dialect,
      hasKey: !!S.settings.apiKey,
      engine: S.engine || S.settings.engine,
      hidden: !!S.settings.translateHidden,
      excluded: isExcluded(),
      allowed: isAllowed(),
      tldOnly: !!S.settings.tldOnly,
      siteOnly: !!S.settings.siteOnly,
      blockList: !!S.settings.blockList,
      allowEmpty:
        (!!S.settings.tldOnly && !SH.parseTldList(S.settings.allowedTlds).length) ||
        (!!S.settings.siteOnly && !SH.parseHostList(S.settings.allowed).length),
      blocked: isBlocked(),
      error: S.lastError
    };
  }

  function setAuto(value, { persist = false, translate = true } = {}) {
    S.autoOn = !!value;
    if (S.autoOn) S.suspended = false;
    if (S.autoOn) {
      S.manual = true;
      if (translate) startPass();
    }
    if (persist) {
      try {
        chrome.storage.local.get({ ktSettings: {} }).then((o) => {
          const s = { ...DEFAULTS, ...(o.ktSettings || {}), autoTranslate: S.autoOn };
          chrome.storage.local.set({ ktSettings: s }).catch(() => {});
        });
      } catch {
        /* ignore */
      }
    }
  }

  /* ---------------------------------------------------------------- */
  /* Messaging                                                         */
  /* ---------------------------------------------------------------- */

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    const type = msg && msg.type;

    if (type === 'krd:ping') {
      sendResponse({ ok: true, state: status() });
      return false;
    }

    if (type === 'krd:translate') {
      S.manual = true;
      startPass({ force: !!msg.force }).then(() => sendResponse({ ok: true, state: status() }));
      return true;
    }

    if (type === 'krd:restore') {
      restore();
      sendResponse({ ok: true, state: status() });
      return false;
    }

    if (type === 'krd:toggleAuto') {
      setAuto(!S.autoOn, { persist: true });
      sendResponse({ ok: true, state: status() });
      return false;
    }

    if (type === 'krd:setAuto') {
      setAuto(!!msg.value, { persist: true, translate: msg.translate !== false });
      sendResponse({ ok: true, state: status() });
      return false;
    }

    if (type === 'krd:settings') {
      const wasBlocked = isBlocked();
      const next = { ...S.settings, ...(msg.settings || {}) };
      const dialectChanged = next.dialect !== S.settings.dialect;
      const hiddenChanged = next.translateHidden !== S.settings.translateHidden;
      S.settings = next;
      if (msg.settings && 'autoTranslate' in msg.settings) {
        setAuto(!!msg.settings.autoTranslate, { persist: false, translate: false });
      }
      if (dialectChanged) S.titleDone = false;
      if (hiddenChanged) startObserver();
      // Turning the domain rules against this site should undo the translation.
      if (!wasBlocked && isBlocked()) restore();
      sendResponse({ ok: true, state: status() });
      return false;
    }

    if (type === 'krd:urlchange') {
      checkUrl();
      sendResponse({ ok: true });
      return false;
    }

    return false;
  });

  // Keep every tab in sync when settings change elsewhere (options page, popup).
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local' || !changes.ktSettings) return;
      const next = SH.normalizeSettings(changes.ktSettings.newValue);
      const dialectChanged = next.dialect !== S.settings.dialect;
      const hiddenChanged = next.translateHidden !== S.settings.translateHidden;
      const autoChanged = !!next.autoTranslate !== S.autoOn;
      S.settings = next;
      if (dialectChanged) S.titleDone = false;
      if (hiddenChanged) startObserver();
      if (autoChanged) setAuto(!!next.autoTranslate, { persist: false, translate: !!next.autoTranslate });
    });
  } catch {
    /* ignore */
  }

  /* ---------------------------------------------------------------- */
  /* Boot                                                              */
  /* ---------------------------------------------------------------- */

  (async () => {
    await loadSettings();
    startObserver();
    startUrlWatcher();

    if (S.settings.autoTranslate && !isBlocked()) {
      S.autoOn = true;
      startPass();
    }

    window.addEventListener('pagehide', flushCache);
    setInterval(flushCache, 30000);
  })();
})();
