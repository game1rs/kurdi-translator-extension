/* Headless tests for background.js: mocks chrome.* and fetch (both Groq and the
   free Google engine), then drives the real message handler. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const root = path.join(__dirname, '..');

function makeContext(opts = {}) {
  const calls = [];
  let listener = null;

  const chrome = {
    runtime: {
      onMessage: { addListener: (fn) => (listener = fn) },
      onInstalled: { addListener: () => {} },
      openOptionsPage: async () => {}
    },
    commands: { onCommand: { addListener: () => {} } },
    webNavigation: {
      onHistoryStateUpdated: { addListener: () => {} },
      onReferenceFragmentUpdated: { addListener: () => {} },
      onCommitted: { addListener: () => {} }
    },
    action: { setBadgeText: () => {}, setBadgeBackgroundColor: () => {} },
    tabs: { sendMessage: async () => {} },
    storage: {
      local: {
        get: async () => ({
          ktSettings: {
            apiKey: opts.apiKey === undefined ? 'gsk_test' : opts.apiKey,
            dialect: opts.dialect || 'ckb'
          }
        })
      }
    }
  };

  const fetch = async (url, init) => {
    const isGoogle = url.includes('clients5.google.com');
    const isMemory = url.includes('api.mymemory.translated.net');
    const body = init && init.body ? JSON.parse(init.body) : null;
    calls.push({ url, body, kind: isGoogle ? 'google' : isMemory ? 'mymemory' : 'groq' });

    const ok = (payload) => ({
      ok: true,
      status: 200,
      headers: { get: () => null },
      json: async () => payload,
      text: async () => JSON.stringify(payload)
    });
    const err = (status) => ({
      ok: false,
      status,
      headers: { get: () => null },
      json: async () => ({}),
      text: async () => '{"error":{"message":"boom"}}'
    });

    if (isGoogle) {
      const mode = opts.google || 'ok';
      if (mode === 'fail') return err(503);
      const params = new URL(url).searchParams.getAll('q');
      let rows = params.map((q) => ['G:' + q, 'en']);
      if (mode === 'mismatch') rows = rows.slice(0, Math.max(1, rows.length - 1));
      return ok(rows);
    }

    if (isMemory) {
      const mode = opts.memory || 'ok';
      const q = new URL(url).searchParams.get('q') || '';
      if (mode === 'fail') {
        return ok({
          responseData: { translatedText: 'MYMEMORY WARNING: YOU USED ALL AVAILABLE FREE TRANSLATIONS' },
          responseStatus: 200
        });
      }
      if (mode === 'error') {
        return ok({ responseData: { translatedText: 'QUERY LENGTH LIMIT EXCEEDED' }, responseStatus: '403' });
      }
      return ok({ responseData: { translatedText: 'M:' + q }, responseStatus: 200 });
    }

    // Groq
    const groqMode = opts.groq || 'ok';
    if (typeof groqMode === 'number') return err(groqMode);
    if (groqMode === 'garbage') {
      return ok({ choices: [{ message: { content: 'sorry, I cannot do that' } }] });
    }
    const content = opts.groqContent || '{"t":["X"]}';
    return ok({ choices: [{ message: { content } }] });
  };

  const ctx = { console, setTimeout, clearTimeout, fetch, chrome, AbortController, AbortSignal, URL };
  ctx.globalThis = ctx;
  ctx.importScripts = (f) => {
    vm.runInContext(fs.readFileSync(path.join(root, f), 'utf8'), ctx, { filename: f });
  };
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(path.join(root, 'background.js'), 'utf8'), ctx, { filename: 'background.js' });
  return { ctx, calls, listener: () => listener };
}

function send(listener, msg) {
  return new Promise((resolve) => {
    const ret = listener(msg, {}, resolve);
    if (ret !== true && ret !== false) resolve(undefined);
  });
}

let pass = 0;
let fail = 0;
function check(name, cond, extra) {
  if (cond) {
    pass += 1;
    console.log(`  PASS  ${name}`);
  } else {
    fail += 1;
    console.log(`  FAIL  ${name}${extra !== undefined ? '  →  ' + JSON.stringify(extra) : ''}`);
  }
}

(async () => {
  /* ---------- Groq happy path ---------- */
  {
    console.log('\nGroq path');
    const { calls, listener } = makeContext({ groqContent: '{"t":["سڵاو","بەخێربێن"]}' });
    const res = await send(listener(), { type: 'krd:translate', items: ['Hello', 'Welcome'] });
    check('translates via Groq', res.ok && res.engine === 'groq', res);
    check('returns both segments', JSON.stringify(res.translations) === '["سڵاو","بەخێربێن"]', res.translations);
    const b = calls[0].body;
    check('model is gpt-oss-120b', b.model === 'openai/gpt-oss-120b', b.model);
    check('json_object mode', b.response_format.type === 'json_object');
    check('endpoint', calls[0].url === 'https://api.groq.com/openai/v1/chat/completions');
    check('auth header', calls[0].body && calls.length === 1);
  }

  /* ---------- Groq broken → free engine silently takes over ---------- */
  {
    console.log('\nAuto fallback when Groq fails');
    const { calls, listener } = makeContext({ groq: 500, google: 'ok' });
    const res = await send(listener(), { type: 'krd:translate', items: ['Hello', 'Welcome'] });
    check('still succeeds', res.ok === true, res);
    check('reports free engine', res.engine === 'google', res.engine);
    check('translations present', JSON.stringify(res.translations) === '["G:Hello","G:Welcome"]', res.translations);
    check('Groq retried twice then abandoned', calls.filter((c) => c.kind === 'groq').length === 3, calls.length);
  }

  /* ---------- Bad key → fallback + cooldown ---------- */
  {
    console.log('\nBad API key');
    const { calls, listener } = makeContext({ groq: 401, google: 'ok' });
    const l = listener();
    const first = await send(l, { type: 'krd:translate', items: ['One', 'Two'] });
    check('first call falls back', first.ok && first.engine === 'google', first);
    const groqAfterFirst = calls.filter((c) => c.kind === 'groq').length;
    check('no pointless Groq retry on 401', groqAfterFirst === 1, groqAfterFirst);

    const second = await send(l, { type: 'krd:translate', items: ['Three', 'Four'] });
    check('second call skips Groq (cooldown)', second.ok && second.engine === 'google', second);
    check(
      'Groq not contacted again',
      calls.filter((c) => c.kind === 'groq').length === groqAfterFirst,
      calls.filter((c) => c.kind === 'groq').length
    );
  }

  /* ---------- Rate limit: one retry, then park Groq ---------- */
  {
    console.log('\nRate limited');
    const { calls, listener } = makeContext({ groq: 429, google: 'ok' });
    const l = listener();
    const first = await send(l, { type: 'krd:translate', items: ['One', 'Two'] });
    check('first batch falls back', first.ok && first.engine === 'google', first);
    check('only one quick retry before giving up', calls.filter((c) => c.kind === 'groq').length === 2, calls.length);

    const second = await send(l, { type: 'krd:translate', items: ['Three', 'Four'] });
    check('next batch skips Groq entirely', second.ok && second.engine === 'google', second);
    check('no extra Groq calls while cooling down', calls.filter((c) => c.kind === 'groq').length === 2, calls.length);
  }

  /* ---------- Unparsable model output ---------- */
  {
    console.log('\nUnparsable Groq output');
    const { listener } = makeContext({ groq: 'garbage', google: 'ok' });
    const res = await send(listener(), { type: 'krd:translate', items: ['Hello', 'World'] });
    check('falls back instead of erroring', res.ok && res.engine === 'google', res);
  }

  /* ---------- Google-only mode ---------- */
  {
    console.log('\nFree engine only (no key at all)');
    const { calls, listener } = makeContext({ apiKey: '' });
    const res = await send(listener(), { type: 'krd:translate', items: ['Hello', 'Welcome'] });
    check('works with no API key', res.ok === true, res);
    check('uses free engine', res.engine === 'google', res.engine);
    check('never calls Groq', calls.every((c) => c.kind === 'google'), calls.map((c) => c.kind));
    check('no Authorization header needed', true);
    const gUrl = calls[0].url;
    check('correct Google language code', gUrl.includes('tl=ckb'), gUrl);
    check('uses the browser translate client', gUrl.includes('client=dict-chrome-ex'), gUrl);
  }

  /* ---------- Dialect → Google language mapping ---------- */
  {
    console.log('\nDialect mapping for the free engine');
    const pairs = [
      ['kmr', 'tl=kmr'],
      ['ckb', 'tl=ckb'],
      ['pnb', 'tl=ckb'],
      ['hac', 'tl=ckb'],
      ['zza', 'tl=kmr'],
      ['kmr-arab', 'tl=kmr']
    ];
    for (const [dialect, expected] of pairs) {
      const { calls, listener } = makeContext({ apiKey: '', dialect });
      await send(listener(), { type: 'krd:translate', items: ['Hello world'] });
      check(`${dialect} → ${expected}`, calls[0].url.includes(expected), calls[0].url);
    }
  }

  /* ---------- Newline fast path vs per-segment fallback ---------- */
  {
    console.log('\nBatch alignment safety');
    const good = makeContext({ apiKey: '', google: 'ok' });
    const r1 = await send(good.listener(), { type: 'krd:translate', items: ['a', 'b', 'c'] });
    check('fast path keeps 1:1 alignment', JSON.stringify(r1.translations) === '["G:a","G:b","G:c"]', r1.translations);
    check('fast path uses a single request', good.calls.length === 1, good.calls.length);

    const bad = makeContext({ apiKey: '', google: 'mismatch' });
    const r2 = await send(bad.listener(), { type: 'krd:translate', items: ['a', 'b', 'c'] });
    check('misaligned batch detected and redone per segment', JSON.stringify(r2.translations) === '["G:a","G:b","G:c"]', r2.translations);
    check('fell back to per-segment requests', bad.calls.length === 4, bad.calls.length);
  }

  /* ---------- Google down, MyMemory catches it ---------- */
  {
    console.log('\nLast-resort engine');
    const { calls, listener } = makeContext({ apiKey: '', google: 'fail', memory: 'ok' });
    const res = await send(listener(), { type: 'krd:translate', items: ['Hello', 'Welcome'] });
    check('falls through to MyMemory', res.ok && res.engine === 'mymemory', res);
    check(
      'MyMemory translations used',
      JSON.stringify(res.translations) === JSON.stringify(['M:Hello', 'M:Welcome']),
      res.translations
    );
    check('MyMemory requests are per segment', calls.filter((c) => c.kind === 'mymemory').length === 2, calls.length);
  }

  /* ---------- Total outage: no crash, no thrown error ---------- */
  {
    console.log('\nEverything down');
    const { listener } = makeContext({ groq: 500, google: 'fail', memory: 'fail' });
    const res = await send(listener(), { type: 'krd:translate', items: ['Hello'] });
    check('does not throw', res && typeof res === 'object', res);
    check('reports no engine', res.engine === 'none', res.engine);
    check('keeps original text (ok:true, untranslated)', res.ok === true && res.translations[0] === 'Hello', res);
  }

  /* ---------- Groq-only mode keeps its error ---------- */
  {
    console.log('\nGroq-only mode');
    const { calls, listener } = makeContext({ groq: 401 });
    const res = await send(listener(), { type: 'krd:translate', items: ['Hello'], engine: 'groq' });
    check('reports the failure instead of hiding it', res.ok === false && /401|key/i.test(res.error), res);
    check('does not silently use the free engine', calls.every((c) => c.kind === 'groq'), calls.map((c) => c.kind));
  }

  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
