"""Generate the extension icons (pure Python, no dependencies)."""
import math
import os
import struct
import zlib

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "icons")
os.makedirs(OUT, exist_ok=True)

SS = 4  # supersampling factor


def sd_round_rect(px, py, cx, cy, hw, hh, r):
    qx = abs(px - cx) - (hw - r)
    qy = abs(py - cy) - (hh - r)
    ax = max(qx, 0.0)
    ay = max(qy, 0.0)
    return math.hypot(ax, ay) + min(max(qx, qy), 0.0) - r


def sd_seg(px, py, ax, ay, bx, by):
    pax, pay = px - ax, py - ay
    bax, bay = bx - ax, by - ay
    denom = bax * bax + bay * bay
    h = 0.0 if denom == 0 else max(0.0, min(1.0, (pax * bax + pay * bay) / denom))
    return math.hypot(pax - bax * h, pay - bay * h)


def smoothstep(edge0, edge1, x):
    if edge0 == edge1:
        return 0.0 if x < edge0 else 1.0
    t = (x - edge0) / (edge1 - edge0)
    t = max(0.0, min(1.0, t))
    return t * t * (3 - 2 * t)


def mix(c1, c2, t):
    return tuple(c1[i] + (c2[i] - c1[i]) * t for i in range(3))


def render(size):
    W = size * SS
    px = 1.0 / W  # one supersampled pixel in normalized 0..1 space

    bg_top = (30, 37, 48)
    bg_bot = (13, 16, 21)
    accent = (245, 80, 54)
    accent_dark = (214, 60, 38)

    # K geometry in 0..1 space
    stem_x = 0.355
    top, bot = 0.255, 0.745
    thick = 0.062
    mid_x, mid_y = 0.435, 0.5
    up_end = (0.675, 0.265)
    lo_end = (0.685, 0.745)

    rows = []
    for y in range(W):
        row = bytearray()
        ny = (y + 0.5) / W
        for x in range(W):
            nx = (x + 0.5) / W

            # Background: rounded square
            d_bg = sd_round_rect(nx, ny, 0.5, 0.5, 0.5, 0.5, 0.235)
            a_bg = 1.0 - smoothstep(-px * 1.2, px * 1.2, d_bg)
            if a_bg <= 0.002:
                row += b"\x00\x00\x00\x00"
                continue

            grad = smoothstep(0.0, 1.0, ny)
            col = mix(bg_top, bg_bot, grad)

            # Subtle inner ring
            d_ring = abs(sd_round_rect(nx, ny, 0.5, 0.5, 0.455, 0.455, 0.2))
            ring = (1.0 - smoothstep(0.0, 0.006, d_ring)) * 0.5
            col = mix(col, (58, 70, 88), ring * 0.55)

            # The K
            d_k = min(
                sd_seg(nx, ny, stem_x, top, stem_x, bot),
                sd_seg(nx, ny, mid_x, mid_y, up_end[0], up_end[1]),
                sd_seg(nx, ny, mid_x, mid_y, lo_end[0], lo_end[1]),
            )
            a_k = 1.0 - smoothstep(thick - px * 1.1, thick + px * 1.1, d_k)
            if a_k > 0.002:
                kcol = mix(accent, accent_dark, smoothstep(0.15, 0.95, ny))
                col = mix(col, kcol, a_k)

            row += bytes(
                (
                    int(max(0, min(255, col[0]))),
                    int(max(0, min(255, col[1]))),
                    int(max(0, min(255, col[2]))),
                    int(max(0, min(255, a_bg * 255))),
                )
            )
        rows.append(row)

    # Downsample
    out_rows = []
    for y in range(size):
        out = bytearray()
        for x in range(size):
            r = g = b = a = 0
            for dy in range(SS):
                src = rows[y * SS + dy]
                base = (x * SS) * 4
                for dx in range(SS):
                    o = base + dx * 4
                    al = src[o + 3]
                    r += src[o] * al
                    g += src[o + 1] * al
                    b += src[o + 2] * al
                    a += al
            n = SS * SS
            if a == 0:
                out += b"\x00\x00\x00\x00"
            else:
                out += bytes((r // a, g // a, b // a, a // n))
        out_rows.append(out)
    return out_rows


def write_png(path, size, rows):
    raw = b"".join(b"\x00" + bytes(r) for r in rows)

    def chunk(tag, data):
        return (
            struct.pack(">I", len(data))
            + tag
            + data
            + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
        )

    png = (
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0))
        + chunk(b"IDAT", zlib.compress(raw, 9))
        + chunk(b"IEND", b"")
    )
    with open(path, "wb") as f:
        f.write(png)


for s in (16, 32, 48, 128):
    write_png(os.path.join(OUT, f"icon{s}.png"), s, render(s))
    print("wrote", f"icons/icon{s}.png")
