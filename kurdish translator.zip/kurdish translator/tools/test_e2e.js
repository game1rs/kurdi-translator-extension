/* End-to-end: loads the real unpacked extension in Chromium, translates a live
   page through the real keyless engine (no API key set), and checks the result. */
const http = require('http');
const path = require('path');
const os = require('os');
const fs = require('fs');
const { chromium } = require('C:/Users/dell/.workbuddy-ai/binaries/node/workspace/node_modules/playwright-core');

const EXT = path.join(__dirname, '..');
const CHROME = 'C:/Users/dell/AppData/Local/ms-playwright/chromium-1247/chrome-win64/chrome.exe';

const PAGE = `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Account settings</title></head>
<body>
  <h1 id="h1">Welcome back</h1>
  <p id="p1">Your account is ready.</p>
  <button id="b1">Save changes</button>
  <a id="a1" href="/next">Open settings</a>
  <pre><code id="code1">const x = 1;</code></pre>
</body></html>`;

const ARABIC = /[\u0600-\u06FF]/;
let failures = 0;
function check(name, cond, extra) {
  if (cond) console.log(`  PASS  ${name}`);
  else {
    failures += 1;
    console.log(`  FAIL  ${name}${extra !== undefined ? '  →  ' + JSON.stringify(extra) : ''}`);
  }
}

(async () => {
  const server = http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(PAGE);
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const port = server.address().port;

  const userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'krd-profile-'));

  const ctx = await chromium.launchPersistentContext(userDataDir, {
    executablePath: CHROME,
    headless: true,
    args: [
      `--disable-extensions-except=${EXT}`,
      `--load-extension=${EXT}`,
      '--no-first-run',
      '--no-default-browser-check'
    ]
  });

  const swErrors = [];
  let sw = ctx.serviceWorkers()[0];
  if (!sw) sw = await ctx.waitForEvent('serviceworker', { timeout: 15000 }).catch(() => null);

  check('extension service worker started', !!sw, sw ? sw.url() : 'none');
  if (!sw) {
    await ctx.close();
    server.close();
    process.exit(1);
  }

  sw.on('console', (m) => {
    if (m.type() === 'error') swErrors.push(m.text());
  });

  const extId = new URL(sw.url()).host;
  console.log('  extension id:', extId);

  const page = await ctx.newPage();
  const pageErrors = [];
  page.on('pageerror', (e) => pageErrors.push(e.message));

  await page.goto(`http://127.0.0.1:${port}/settings`);
  await page.waitForTimeout(800);

  // Confirm the content script is live before translating.
  const alive = await sw.evaluate(async () => {
    const tabs = await chrome.tabs.query({ url: 'http://127.0.0.1/*' });
    if (!tabs.length) return 'no tab';
    try {
      const r = await chrome.tabs.sendMessage(tabs[0].id, { type: 'krd:ping' });
      return r && r.ok ? 'ok' : 'bad reply';
    } catch (e) {
      return 'no content script: ' + e.message;
    }
  });
  check('content script reachable from the service worker', alive === 'ok', alive);

  console.log('\n— manual translate, no API key, real network —');
  const t0 = Date.now();
  await sw.evaluate(async () => {
    const tabs = await chrome.tabs.query({ url: 'http://127.0.0.1/*' });
    return chrome.tabs.sendMessage(tabs[0].id, { type: 'krd:translate' });
  });
  await page.waitForTimeout(2500);

  const h1 = await page.textContent('#h1');
  const p1 = await page.textContent('#p1');
  const b1 = await page.textContent('#b1');
  const a1 = await page.textContent('#a1');
  const code = await page.textContent('#code1');
  const elapsed = Date.now() - t0;

  check('heading translated to Kurdish script', ARABIC.test(h1 || '') && h1 !== 'Welcome back', h1);
  check('paragraph translated', ARABIC.test(p1 || '') && p1 !== 'Your account is ready.', p1);
  check('button translated', ARABIC.test(b1 || '') && b1 !== 'Save changes', b1);
  check('link translated', ARABIC.test(a1 || '') && a1 !== 'Open settings', a1);
  check('code block untouched', code === 'const x = 1;', code);
  check('no page errors', pageErrors.length === 0, pageErrors);
  check('no service worker errors', swErrors.length === 0, swErrors);

  const status = await sw.evaluate(async () => {
    const tabs = await chrome.tabs.query({ url: 'http://127.0.0.1/*' });
    const r = await chrome.tabs.sendMessage(tabs[0].id, { type: 'krd:ping' });
    return r.state;
  });
  check('reports which engine served it', status.engine === 'google' || status.engine === 'mymemory', status.engine);
  check('counts translated segments', status.translated >= 4, status.translated);
  console.log(`  (round trip: ${elapsed} ms, engine: ${status.engine})`);

  const overlay = await page.evaluate(() =>
    document.querySelectorAll('[id*="krd"],[class*="krd"]').length
  );
  check('nothing injected into the page', overlay === 0, overlay);

  console.log('\n— restore —');
  await sw.evaluate(async () => {
    const tabs = await chrome.tabs.query({ url: 'http://127.0.0.1/*' });
    return chrome.tabs.sendMessage(tabs[0].id, { type: 'krd:restore' });
  });
  await page.waitForTimeout(300);
  check('original text restored', (await page.textContent('#h1')) === 'Welcome back', await page.textContent('#h1'));

  console.log('\n— auto translate on a fresh page —');
  await sw.evaluate(async () => {
    const { ktSettings } = await chrome.storage.local.get({ ktSettings: {} });
    await chrome.storage.local.set({
      ktSettings: { ...ktSettings, autoTranslate: true, apiKey: '' }
    });
  });
  const page2 = await ctx.newPage();
  page2.on('pageerror', (e) => pageErrors.push(e.message));
  await page2.goto(`http://127.0.0.1:${port}/other`);
  await page2.waitForTimeout(3000);
  const autoH1 = await page2.textContent('#h1');
  check('auto-translated without any click', ARABIC.test(autoH1 || '') && autoH1 !== 'Welcome back', autoH1);
  check('still no page errors', pageErrors.length === 0, pageErrors);

  console.log('\n— URL change on the same tab —');
  await page2.evaluate(() => {
    history.pushState({}, '', '/step-two');
    document.querySelector('#h1').textContent = 'Another screen';
  });
  await page2.waitForTimeout(3000);
  const navH1 = await page2.textContent('#h1');
  check('content after link change translated', ARABIC.test(navH1 || '') && navH1 !== 'Another screen', navH1);

  check('no service worker errors at the end', swErrors.length === 0, swErrors);

  await ctx.close();
  server.close();

  console.log(`\n${failures === 0 ? 'ALL E2E CHECKS PASSED' : failures + ' E2E CHECK(S) FAILED'}`);
  process.exit(failures ? 1 : 0);
})().catch((e) => {
  console.error('E2E CRASHED:', e);
  process.exit(1);
});
