/* Screenshot the popup and options pages inside a real extension context. */
const path = require('path');
const os = require('os');
const fs = require('fs');
const { chromium } = require('C:/Users/dell/.workbuddy-ai/binaries/node/workspace/node_modules/playwright-core');

const EXT = path.join(__dirname, '..');
const CHROME = 'C:/Users/dell/AppData/Local/ms-playwright/chromium-1247/chrome-win64/chrome.exe';

(async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'krd-shot-'));
  const ctx = await chromium.launchPersistentContext(dir, {
    executablePath: CHROME,
    headless: true,
    args: [`--disable-extensions-except=${EXT}`, `--load-extension=${EXT}`, '--no-first-run']
  });

  let sw = ctx.serviceWorkers()[0];
  if (!sw) sw = await ctx.waitForEvent('serviceworker', { timeout: 15000 });
  const id = new URL(sw.url()).host;

  // Seed a key so the popup shows its normal state.
  await sw.evaluate(async () => {
    await chrome.storage.local.set({
      ktSettings: { apiKey: 'gsk_demo_key_for_screenshot', engine: 'auto', dialect: 'ckb' }
    });
  });

  const popup = await ctx.newPage();
  await popup.setViewportSize({ width: 344, height: 430 });
  await popup.goto(`chrome-extension://${id}/popup.html`);
  await popup.waitForTimeout(700);
  await popup.screenshot({ path: path.join(EXT, 'tools', 'shot-popup.png') });

  const options = await ctx.newPage();
  await options.setViewportSize({ width: 900, height: 1400 });
  await options.goto(`chrome-extension://${id}/options.html`);
  await options.waitForTimeout(700);
  await options.screenshot({ path: path.join(EXT, 'tools', 'shot-options.png'), fullPage: true });

  console.log('screenshots written');
  await ctx.close();
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
