/* Benchmark: how long until a dense page is actually translated.
   Loads the real extension and times it with the keyless engine. */
const http = require('http');
const path = require('path');
const os = require('os');
const fs = require('fs');
const { chromium } = require('C:/Users/dell/.workbuddy-ai/binaries/node/workspace/node_modules/playwright-core');

const EXT = path.join(__dirname, '..');
const CHROME = 'C:/Users/dell/AppData/Local/ms-playwright/chromium-1247/chrome-win64/chrome.exe';

const WORDS = [
  'Account settings', 'Save your changes', 'Sign in to continue', 'Forgot your password',
  'Download the app', 'Learn more about pricing', 'Contact support', 'Privacy policy',
  'Notifications are turned off', 'Your order has shipped', 'Add to cart', 'Continue reading',
  'Search results', 'No items found', 'Terms of service', 'Delete this file',
  'Upload a new photo', 'Change your plan', 'Billing history', 'Invite a teammate'
];

function buildPage(count) {
  let body = '<h1>Benchmark page</h1>';
  for (let i = 0; i < count; i += 1) {
    const text = `${WORDS[i % WORDS.length]} ${i}`;
    body += `<div class="row"><span>${text}</span><button>${WORDS[(i + 3) % WORDS.length]} ${i}</button></div>`;
  }
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Benchmark</title></head><body>${body}</body></html>`;
}

(async () => {
  const N = Number(process.argv[2] || 120);
  const page_html = buildPage(N);

  const server = http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(page_html);
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const port = server.address().port;

  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'krd-bench-'));
  const ctx = await chromium.launchPersistentContext(dir, {
    executablePath: CHROME,
    headless: true,
    args: [`--disable-extensions-except=${EXT}`, `--load-extension=${EXT}`, '--no-first-run']
  });

  let sw = ctx.serviceWorkers()[0] || (await ctx.waitForEvent('serviceworker'));
  const swErrors = [];
  sw.on('console', (m) => m.type() === 'error' && swErrors.push(m.text()));

  const tune = {
    maxItems: Number(process.env.BENCH_ITEMS || 0) || undefined,
    maxChars: Number(process.env.BENCH_CHARS || 0) || undefined,
    concurrency: Number(process.env.BENCH_CONC || 0) || undefined
  };

  await sw.evaluate(async (extra) => {
    const settings = { apiKey: '', engine: 'auto', dialect: 'ckb', autoTranslate: true };
    for (const [k, v] of Object.entries(extra)) if (v) settings[k] = v;
    await chrome.storage.local.set({ ktSettings: settings });
    await chrome.storage.local.remove('ktCache');
  }, tune);

  const page = await ctx.newPage();
  const t0 = Date.now();
  await page.goto(`http://127.0.0.1:${port}/bench`);

  // Poll until the page stops gaining translated segments.
  let last = -1;
  let stable = 0;
  let firstNonZero = 0;
  for (;;) {
    const n = await sw.evaluate(async () => {
      const tabs = await chrome.tabs.query({ url: 'http://127.0.0.1/*' });
      if (!tabs.length) return 0;
      try {
        const r = await chrome.tabs.sendMessage(tabs[0].id, { type: 'krd:ping' });
        return r.state.translated;
      } catch {
        return 0;
      }
    });
    if (n > 0 && !firstNonZero) firstNonZero = Date.now() - t0;
    if (n === last) {
      stable += 1;
      if (stable >= 4 && n > 0) break;
    } else {
      stable = 0;
      last = n;
    }
    if (Date.now() - t0 > 60000) break;
    await page.waitForTimeout(150);
  }

  const total = Date.now() - t0;
  const expected = N * 2 + 1;

  console.log(`segments on page : ~${expected}`);
  console.log(`translated       : ${last}`);
  console.log(`first paint      : ${firstNonZero} ms  (first batch visible)`);
  console.log(`fully translated : ${total} ms`);
  console.log(`errors           : ${swErrors.length ? swErrors.join(' | ') : 'none'}`);

  // Second visit: cache should make it near-instant.
  const t1 = Date.now();
  const page2 = await ctx.newPage();
  await page2.goto(`http://127.0.0.1:${port}/bench`);
  await page2.waitForTimeout(1200);
  const cached = await page2.evaluate(() => document.querySelector('h1').textContent);
  console.log(`cached reload    : ${Date.now() - t1} ms, h1="${cached}"`);

  await ctx.close();
  server.close();
})().catch((e) => {
  console.error('BENCH FAILED:', e);
  process.exit(1);
});
