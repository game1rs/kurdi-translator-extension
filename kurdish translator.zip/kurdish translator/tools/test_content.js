/* Real-browser test for content.js: serves a fixture page, injects the content
   script with a stubbed chrome.* API, and verifies what actually changed in the DOM. */
const http = require('http');
const path = require('path');
const { chromium } = require('C:/Users/dell/.workbuddy-ai/binaries/node/workspace/node_modules/playwright-core');

const ROOT = path.join(__dirname, '..');
const CHROME = 'C:/Users/dell/AppData/Local/ms-playwright/chromium-1247/chrome-win64/chrome.exe';

const PAGE = `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>My Dashboard</title>
<style>
  .hidden { display: none; }
  .ghost { visibility: hidden; }
</style></head>
<body>
  <h1 id="h1">Welcome back</h1>
  <p id="p1">  Your account is ready.  </p>
  <a id="a1" href="/x" aria-label="Open the settings page">Open settings</a>
  <button id="b1" title="Save your changes">Save changes</button>
  <img id="img1" alt="Company logo" src="data:," />
  <pre><code id="code1">const x = "Hello world";</code></pre>
  <script>window.__inline = "Hello from script";</script>
  <div class="hidden"><span id="hidden1">Secret hidden text</span></div>
  <div class="ghost"><span id="ghost1">Ghost text</span></div>
  <input id="inp" value="typed text" placeholder="Search here" />
  <textarea id="ta">Textarea content</textarea>
  <div id="editable" contenteditable="true">Editable text</div>
  <div translate="no" id="notrans"><span id="notrans1">Do not translate me</span></div>
  <ul id="list">
    <li id="li1">First item</li>
    <li id="li2">Second item</li>
    <li id="li3">Third item</li>
  </ul>
  <p id="num">1,234</p>
  <p id="empty"> </p>
  <div id="tail"></div>
</body></html>`;

const STUB = `
  window.__krdCalls = [];
  const sendMessage = async (msg) => {
    window.__krdCalls.push(msg);
    if (msg.type === 'krd:translate') {
      return { ok: true, translations: msg.items.map((t) => 'TR:' + t.trim()) };
    }
    return { ok: true };
  };
  window.chrome = {
    runtime: { sendMessage, onMessage: { addListener: (fn) => { window.__krdListener = fn; } } },
    storage: {
      local: {
        get: async (defs) => ({
          ktSettings: window.__krdSettings || { apiKey: 'gsk_test', dialect: 'ckb' },
          ktCache: {}
        }),
        set: async () => {}
      },
      onChanged: { addListener: () => {} }
    }
  };
`;

let failures = 0;
function check(name, cond, extra) {
  if (cond) console.log(`  PASS  ${name}`);
  else {
    failures += 1;
    console.log(`  FAIL  ${name}${extra !== undefined ? '  →  ' + JSON.stringify(extra) : ''}`);
  }
}

(async () => {
  const server = http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(PAGE);
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const port = server.address().port;
  const url = `http://127.0.0.1:${port}/dashboard`;

  const browser = await chromium.launch({ executablePath: CHROME, headless: true });
  const page = await browser.newPage();
  page.on('pageerror', (e) => console.log('  [pageerror]', e.message));

  await page.addInitScript(STUB);
  await page.goto(url);

  await page.addScriptTag({ path: path.join(ROOT, 'shared.js') });
  await page.addScriptTag({ path: path.join(ROOT, 'content.js') });
  await page.waitForTimeout(150);

  const text = (sel) => page.evaluate((s) => {
    const el = document.querySelector(s);
    return el ? el.textContent : null;
  }, sel);

  console.log('\n— before translation —');
  check('fixture loads untranslated', (await text('#h1')) === 'Welcome back');

  // Trigger a manual pass through the real message listener.
  await page.evaluate(() => window.__krdListener({ type: 'krd:translate' }, {}, () => {}));
  await page.waitForTimeout(600);

  console.log('\n— after translation —');
  check('heading translated', (await text('#h1')) === 'TR:Welcome back', await text('#h1'));
  check('link text translated', (await text('#a1')) === 'TR:Open settings', await text('#a1'));
  check('button translated', (await text('#b1')) === 'TR:Save changes', await text('#b1'));
  check('list item 1 translated', (await text('#li1')) === 'TR:First item', await text('#li1'));
  check('list item 3 translated', (await text('#li3')) === 'TR:Third item', await text('#li3'));

  const p1 = await page.evaluate(() => document.querySelector('#p1').firstChild.nodeValue);
  check('leading/trailing whitespace preserved', p1 === '  TR:Your account is ready.  ', p1);

  check('<pre><code> untouched', (await text('#code1')) === 'const x = "Hello world";', await text('#code1'));
  check('display:none text translated ahead of time', (await text('#hidden1')) === 'TR:Secret hidden text', await text('#hidden1'));
  check('visibility:hidden translated ahead of time', (await text('#ghost1')) === 'TR:Ghost text', await text('#ghost1'));
  check('input value untouched', (await page.evaluate(() => document.querySelector('#inp').value)) === 'typed text');

  const attr = (sel, name) => page.evaluate(([s2, n]) => document.querySelector(s2).getAttribute(n), [sel, name]);
  check('title attribute translated', (await attr('#b1', 'title')) === 'TR:Save your changes', await attr('#b1', 'title'));
  check('placeholder translated', (await attr('#inp', 'placeholder')) === 'TR:Search here', await attr('#inp', 'placeholder'));
  check('aria-label translated', (await attr('#a1', 'aria-label')) === 'TR:Open the settings page', await attr('#a1', 'aria-label'));
  check('alt translated', (await attr('#img1', 'alt')) === 'TR:Company logo', await attr('#img1', 'alt'));
  check('textarea untouched', (await text('#ta')) === 'Textarea content', await text('#ta'));
  check('contenteditable untouched', (await text('#editable')) === 'Editable text', await text('#editable'));
  check('translate="no" untouched', (await text('#notrans1')) === 'Do not translate me', await text('#notrans1'));
  check('numeric-only node untouched', (await text('#num')) === '1,234', await text('#num'));
  check('inline <script> text untouched', (await page.evaluate(() => window.__inline)) === 'Hello from script');

  const title = await page.title();
  check('tab title translated', title === 'TR:My Dashboard', title);

  const overlay = await page.evaluate(() =>
    document.querySelectorAll('[id*="krd"],[class*="krd"],[id*="translate-banner"]').length
  );
  check('no UI injected into the page (silent)', overlay === 0, overlay);

  const calls = await page.evaluate(() => window.__krdCalls.filter((c) => c.type === 'krd:translate'));
  const batches = calls.filter((c) => c.items.length > 1);
  check('batched multiple nodes per request', batches.length > 0, calls.map((c) => c.items.length));
  check('every batch under maxItems', calls.every((c) => c.items.length <= 32), calls.map((c) => c.items.length));
  check('every batch under maxChars', calls.every((c) => c.items.join('').length <= 2000));

  console.log('\n— restore —');
  await page.evaluate(() => window.__krdListener({ type: 'krd:restore' }, {}, () => {}));
  await page.waitForTimeout(200);
  check('heading restored', (await text('#h1')) === 'Welcome back', await text('#h1'));
  check('whitespace restored exactly', (await page.evaluate(() => document.querySelector('#p1').firstChild.nodeValue)) === '  Your account is ready.  ');
  check('title restored', (await page.title()) === 'My Dashboard', await page.title());
  check('title attribute restored', (await attr('#b1', 'title')) === 'Save your changes', await attr('#b1', 'title'));
  check('placeholder restored', (await attr('#inp', 'placeholder')) === 'Search here', await attr('#inp', 'placeholder'));

  console.log('\n— dynamic content (infinite scroll / SPA) —');
  await page.evaluate(() => window.__krdListener({ type: 'krd:translate' }, {}, () => {}));
  await page.waitForTimeout(500);
  await page.evaluate(() => {
    const d = document.createElement('div');
    d.innerHTML = '<p id="late1">Late loaded paragraph</p>';
    document.querySelector('#tail').appendChild(d);
  });
  await page.waitForTimeout(1400);
  check('newly injected node translated', (await text('#late1')) === 'TR:Late loaded paragraph', await text('#late1'));

  console.log('\n— URL change (SPA navigation) —');
  await page.evaluate(() => {
    history.pushState({}, '', '/another-page');
    document.querySelector('#tail').innerHTML = '<h2 id="spa1">SPA page two</h2>';
  });
  await page.waitForTimeout(2600);
  check('content after URL change translated', (await text('#spa1')) === 'TR:SPA page two', await text('#spa1'));

  console.log('\n— cache —');
  const before = await page.evaluate(() => window.__krdCalls.filter((c) => c.type === 'krd:translate').length);
  await page.evaluate(() => window.__krdListener({ type: 'krd:translate' }, {}, () => {}));
  await page.waitForTimeout(700);
  const after = await page.evaluate(() => window.__krdCalls.filter((c) => c.type === 'krd:translate').length);
  check('second pass makes no extra API calls (cache hit)', after - before <= 1, { before, after });


  /* ---------- domain rules ---------- */
  console.log('\n— domain matching —');
  {
    const hc = await page.evaluate(() => {
      const H = window.KRD_SHARED.hostInList;
      const T = window.KRD_SHARED.hostInTldList;
      return {
        // domain list
        domain: H('mail.google.com', 'google.com'),
        exact: H('google.com', 'google.com'),
        lookalike: H('notgoogle.com', 'google.com'),
        star: H('a.b.com', '*.b.com'),
        yt: H('www.youtube.com', 'youtube.com'),
        ytMobile: H('m.youtube.com', 'youtube.com'),
        ytLookalike: H('notyoutube.com', 'youtube.com'),
        bareNoDot: H('example.com', 'com'),
        // tld list
        tldDot: T('shop.example.com', '.com'),
        tldBare: T('example.com', 'com'),
        tldUk: T('bbc.co.uk', '.co.uk'),
        tldMiss: T('example.org', '.com'),
        tldNotDomain: !T('example.com', 'youtube.com')
      };
    });
    check('a plain domain covers its subdomains', hc.yt && hc.ytMobile, hc);
    check('lookalike host rejected', !hc.ytLookalike && !hc.lookalike, hc);
    check('domain list ignores bare endings', !hc.bareNoDot, hc);
    check('TLD list matches whole endings', hc.tldDot && hc.tldBare && hc.tldUk, hc);
    check('TLD list rejects non-matching', !hc.tldMiss && hc.tldNotDomain, hc);
    check('wildcard sugar accepted', hc.star, hc);
  }

  console.log('\n— allow list blocks, override forces —');
  {
    const p = await browser.newPage();
    p.on('pageerror', (e) => console.log('  [pageerror]', e.message));
    await p.addInitScript(STUB);
    await p.goto(url);
    await p.evaluate(() => {
      window.__krdSettings = { apiKey: 'gsk_test', dialect: 'ckb', tldOnly: true, allowedTlds: '.net\n.org' };
    });
    await p.addScriptTag({ path: path.join(ROOT, 'shared.js') });
    await p.addScriptTag({ path: path.join(ROOT, 'content.js') });
    await p.waitForTimeout(150);

    await p.evaluate(() => window.__krdListener({ type: 'krd:translate' }, {}, () => {}));
    await p.waitForTimeout(600);
    check('site outside the allow list stays English', (await p.textContent('#h1')) === 'Welcome back', await p.textContent('#h1'));

    const st = await p.evaluate(() => {
      let out = null;
      window.__krdListener({ type: 'krd:ping' }, {}, (r) => { out = r.state; });
      return out;
    });
    check('status reports it as blocked', st && st.blocked === true && st.allowed === false, st);

    await p.evaluate(() => window.__krdListener({ type: 'krd:translate', force: true }, {}, () => {}));
    await p.waitForTimeout(700);
    check('"translate anyway" overrides the rule', (await p.textContent('#h1')) === 'TR:Welcome back', await p.textContent('#h1'));

    // Now put the actual host on the list: it should translate with no override.
    await p.evaluate(() => window.__krdListener({ type: 'krd:settings', settings: { tldOnly: false, siteOnly: true, allowed: '127.0.0.1' } }, {}, () => {}));
    await p.evaluate(() => window.__krdListener({ type: 'krd:restore' }, {}, () => {}));
    await p.evaluate(() => window.__krdListener({ type: 'krd:translate' }, {}, () => {}));
    await p.waitForTimeout(800);
    check('exact domain on the list is translated', (await p.textContent('#h1')) === 'TR:Welcome back', await p.textContent('#h1'));

    await p.close();
  }

  console.log('\n— each rule switches independently —');
  {
    const p = await browser.newPage();
    p.on('pageerror', (e) => console.log('  [pageerror]', e.message));
    await p.addInitScript(STUB);
    await p.goto(url);
    await p.evaluate(() => {
      window.__krdSettings = { apiKey: 'gsk_test', dialect: 'ckb', siteOnly: true, allowed: 'youtube.com' };
    });
    await p.addScriptTag({ path: path.join(ROOT, 'shared.js') });
    await p.addScriptTag({ path: path.join(ROOT, 'content.js') });
    await p.waitForTimeout(150);

    await p.evaluate(() => window.__krdListener({ type: 'krd:translate' }, {}, () => {}));
    await p.waitForTimeout(600);
    check('site rule blocks an unlisted site', (await p.textContent('#h1')) === 'Welcome back', await p.textContent('#h1'));

    await p.evaluate(() => window.__krdListener({ type: 'krd:settings', settings: { siteOnly: false } }, {}, () => {}));
    await p.evaluate(() => window.__krdListener({ type: 'krd:translate' }, {}, () => {}));
    await p.waitForTimeout(700);
    check('switching the site rule off translates again', (await p.textContent('#h1')) === 'TR:Welcome back', await p.textContent('#h1'));

    await p.evaluate(() =>
      window.__krdListener({ type: 'krd:settings', settings: { blockList: true, excluded: '127.0.0.1' } }, {}, () => {})
    );
    await p.waitForTimeout(300);
    check('block rule undoes the translation when it starts applying', (await p.textContent('#h1')) === 'Welcome back', await p.textContent('#h1'));

    await p.evaluate(() => window.__krdListener({ type: 'krd:settings', settings: { blockList: false } }, {}, () => {}));
    await p.evaluate(() => window.__krdListener({ type: 'krd:translate' }, {}, () => {}));
    await p.waitForTimeout(700);
    check('block rule switched off is ignored', (await p.textContent('#h1')) === 'TR:Welcome back', await p.textContent('#h1'));

    await p.close();
  }

  console.log('\n— hidden text skipped, then translated on reveal —');
  {
    const p = await browser.newPage();
    p.on('pageerror', (e) => console.log('  [pageerror]', e.message));
    await p.addInitScript(STUB);
    await p.goto(url);
    await p.evaluate(() => {
      window.__krdSettings = {
        apiKey: 'gsk_test',
        dialect: 'ckb',
        translateHidden: false,
        translateAttributes: false
      };
    });
    await p.addScriptTag({ path: path.join(ROOT, 'shared.js') });
    await p.addScriptTag({ path: path.join(ROOT, 'content.js') });
    await p.waitForTimeout(150);
    await p.evaluate(() => window.__krdListener({ type: 'krd:translate' }, {}, () => {}));
    await p.waitForTimeout(700);

    check('hidden text left alone when the option is off', (await p.textContent('#hidden1')) === 'Secret hidden text', await p.textContent('#hidden1'));

    await p.evaluate(() => { document.querySelector('.hidden').style.display = 'block'; });
    await p.waitForTimeout(1400);
    check('translated the moment it is revealed', (await p.textContent('#hidden1')) === 'TR:Secret hidden text', await p.textContent('#hidden1'));
    await p.close();
  }

  await browser.close();
  server.close();

  console.log(`\n${failures === 0 ? 'ALL CHECKS PASSED' : failures + ' CHECK(S) FAILED'}`);
  process.exit(failures ? 1 : 0);
})().catch((e) => {
  console.error('TEST CRASHED:', e);
  process.exit(1);
});
