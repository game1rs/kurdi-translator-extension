# Kurdî Translate

A Chrome extension that translates any web page into Kurdish — **silently**. No banner, no
overlay, no "page translated" popup. The text is simply swapped in place.

Powered by **Groq** (`openai/gpt-oss-120b`) with a **free keyless fallback chain**, so it
keeps working even when the API is down, rate-limited, or you never added a key.

---

## Install (2 minutes)

1. Open `chrome://extensions` in Chrome / Edge / Brave.
2. Turn on **Developer mode** (top right).
3. Click **Load unpacked** and pick this folder (the one containing `manifest.json`).
4. Pin the extension to the toolbar.

It already works without a key — the free engine handles translation out of the box.

---

## Where to put the API key

**Extension icon → Settings** (or right-click the icon → *Options*).

Paste your key into the **Groq API key** field and press **Save settings**.

Get a free key at <https://console.groq.com/keys> — it looks like `gsk_xxxxxxxx...`.

The key is stored only on your machine in `chrome.storage.local`. It is never sent anywhere
except `api.groq.com`.

> The key is **optional**. Without it, translation runs on the free built-in engine.
> With it, `openai/gpt-oss-120b` does the work and produces noticeably better Kurdish.

---

## Features

| Feature | Where |
| --- | --- |
| Translate this page | Popup button, or `Alt+T` |
| Auto translate every page | Popup toggle, or `Alt+A` |
| Re-translate when the URL changes (SPAs, YouTube, X, Reddit, infinite feeds) | Popup toggle |
| Restore the original text | Popup button, or `Alt+R` |
| Pick the Kurdish dialect | Popup dropdown / Settings |
| Translate hidden text before it appears | Settings → Behaviour |
| Translate `title` / `placeholder` / `aria-label` / `alt` | Settings → Behaviour |
| Domain rules (allow / block) | Settings → Where it translates, plus one-click in the popup |
| Translation cache (repeat pages cost nothing) | Automatic |

Shortcuts can be rebound at `chrome://extensions/shortcuts`.

### Hidden elements are translated up front

Menus, modals, dropdowns, tooltips and lazy-loaded panels are translated while still
invisible, so nothing pops open in English a second later. Same for `title`, `placeholder`,
`aria-label` and `alt` — the text that only shows on hover.

Both can be switched off individually if you would rather save tokens.

### What it deliberately does not touch

`<code>`, `<pre>`, form values, `contenteditable` regions, `<script>`/`<style>`, anything
marked `translate="no"` or `.notranslate`, and text with no letters (numbers, punctuation,
symbols). URLs, e-mail addresses, numbers and `{placeholders}` are preserved by the prompt.

### Restore means restore

After **Restore original**, the extension stays hands-off on that page until you ask it to
translate again — otherwise the observer would immediately translate it back.

---

## Where it translates — three independent rules

Each rule in Settings → *Where it translates* has **its own switch**. Turning a rule off
keeps the list you typed, so you can disable one without losing your work.

| Rule | Example entry | What it does |
| --- | --- | --- |
| **Only these TLDs** | `.com`, `.net`, `.co.uk` | Allows every site under those endings |
| **Only these sites** | `youtube.com` | Allows that domain and all its subdomains (`www.`, `m.`, …) |
| **Never translate these sites** | `mail.google.com` | Blocks — always wins over the two above |

How the switches combine:

- All three off → every site is translated (default).
- An **allow** rule that is on is a hard filter: a site that does not match is skipped.
- Both allow rules on → a site must satisfy **both** (`.com` + `youtube.com` = only YouTube).
- The **block** rule always overrides the allow rules.

Entries are forgiving: `https://www.youtube.com/watch?v=…`, `*.youtube.com` and
`www.youtube.com` all normalise to `youtube.com`.

The popup has a one-click shortcut for the site you are on — *Never translate this site*, or
*Add to translate-only list* when the site rule is active — and it stores `youtube.com`
rather than `www.youtube.com`, so the entry covers every subdomain.

When a rule blocks the current page, the popup says why and offers **Translate anyway** for a
one-off override.

---

## Translation engines

Three engines, tried in order. Failures are handled silently — you never see an error on the
page, you just get translated text.

1. **Groq · `openai/gpt-oss-120b`** — best Kurdish quality, best dialect coverage.
   Needs your API key.
2. **Free built-in engine** (Google's browser translate endpoint) — no key, no signup,
   supports Sorani and Kurmanji. Batches up to ~35 segments per request with exact 1:1
   mapping, so alignment can never drift.
3. **MyMemory** — last resort, Sorani-focused, 500 characters per query.

If Groq rejects the key, the model is unavailable, or it rate-limits, the extension stops
calling it for a while instead of retrying on every batch — one quick retry, then the free
engine carries the page. That is what keeps big pages from crawling on the free Groq tier.

### Engine modes (Settings → Translation engine)

- **Auto** (default) — Groq first, free engine as the safety net.
- **Free engine only** — fastest, no API key needed at all.
- **Groq only** — no fallback; errors are reported in the popup.

---

## Speed

Measured on a synthetic 241-segment page with the free engine:

| | first text visible | fully translated |
| --- | --- | --- |
| This build (32 segments / 2000 chars / 8 parallel) | ~1.2 s | **~2.0 s** |
| Previous settings (35 / 2200 / 4) | ~1.4 s | ~2.8 s |

What made the difference:

- **Wide parallelism.** 8 requests in flight instead of 4.
- **Batching tuned by measurement.** Tiny batches (14 segments) looked faster in isolation
  but were slower end to end — per-request overhead dominates once connections are warm.
- **A much shorter system prompt.** It rides along on every single request; the old one was
  ~400 tokens per call, now ~90.
- **No per-node visibility check** when hidden elements are included, which used to force a
  style/layout calculation for every text node on the page.
- **Incremental work.** Mutations queue only the changed subtree instead of re-walking the
  whole document.
- **The tab title is translated in parallel** with the body instead of after it.
- **Timeouts on every request** (20 s Groq, 12 s free engine) so one stalled socket cannot
  hold a worker hostage.

Settings → Performance lets you tune all of it. More parallel requests is the biggest lever;
lower it if Groq rate-limits you.

---

## Dialects

| Dialect | Script | Groq | Free engine |
| --- | --- | --- | --- |
| Sorani (Central Kurdish) | Arabic | ✅ | ✅ native |
| Kurmanji (Northern Kurdish) | Latin | ✅ | ✅ native |
| Badini (Kurmanji) | Arabic | ✅ | ⚠️ Kurmanji in Latin |
| Palewani (Southern Kurdish) | Arabic | ✅ | ⚠️ falls back to Sorani |
| Hawrami (Gorani) | Arabic | ✅ | ⚠️ falls back to Sorani |
| Zazaki (Dimli) | Latin | ✅ | ⚠️ falls back to Kurmanji |

Google only ships Sorani and Kurmanji, so for the three rarer dialects the free engine
substitutes the closest language it has rather than failing. With a Groq key you get the
real dialect.

---

## Troubleshooting

**Nothing happens on a page.**
Chrome blocks extensions on `chrome://`, the Web Store and PDF viewer tabs. Reload the page
after installing; the content script only attaches to pages loaded afterwards.

**Popup says "Reload the page to activate".**
Same as above — the tab predates the install.

**Popup says "Skipped · …".**
One of the three domain rules is blocking this site. The message names which one; open
Settings and flip that switch off, or use **Translate anyway**.

**It translated the wrong dialect.**
Check the popup dropdown. Badini/Palewani/Hawrami/Zazaki need the Groq key to be exact.

**Translation stopped midway.**
The page hit the *Max characters per page* cap. Raise it in Settings, or click translate again.

**Groq errors.**
Set the engine to **Auto** — failures fall through to the free engine automatically.

---

## Files

```
manifest.json     MV3 manifest
shared.js         defaults, dialect table, host rules, engine URLs
background.js     service worker: Groq client, free engines, tab orchestration
content.js        silent DOM translation, batching, cache, observers
popup.html/js     toolbar panel
options.html/js   settings page (API key lives here)
icons/            generated PNGs
tools/            test harnesses, benchmark, icon generator (not needed at runtime)
```

## Tests

```
node tools/test_background.js   # engine chain, fallbacks, parsing (43 checks)
node tools/test_content.js      # real Chromium DOM behaviour (50 checks)
node tools/test_e2e.js          # real extension, real network, no API key
node tools/bench.js 120         # speed on a 241-segment page
```

## Privacy

Page text is sent to Groq (with your key) or to the free engine endpoints for translation,
and nowhere else. No analytics, no tracking, no accounts. The cache stays on your device.
Use the block list for sensitive sites.
