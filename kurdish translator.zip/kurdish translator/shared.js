/* Kurdî Translate — shared constants (loaded by the service worker, content script, popup and options page) */
(() => {
  if (globalThis.KRD_SHARED) return;

  const DIALECTS = {
    ckb: {
      label: 'Sorani (Central Kurdish)',
      native: 'کوردیی سۆرانی',
      instruction:
        'Central Kurdish / Sorani written in the Arabic (Perso-Arabic) script. Use standard Sorani letters ڕ ڵ ێ ۆ ڤ چ پ ژ گ and Sorani grammar and vocabulary (e.g. دەکات، ئەم، بۆ، لە، بەکارهێنەر، پەڕە). Do not use Kurmanji forms.'
    },
    kmr: {
      label: 'Kurmanji (Northern Kurdish)',
      native: 'Kurmancî',
      instruction:
        'Northern Kurdish / Kurmanji written in the Latin Hawar alphabet (ç ê î ş û). Use Kurmanji grammar and vocabulary (e.g. dikim, ev, ji bo, li ser, bikarhêner, rûpel). Do not use Sorani forms.'
    },
    'kmr-arab': {
      label: 'Badini (Kurmanji, Arabic script)',
      native: 'بادینی',
      instruction:
        'Badini — the Northern Kurdish (Kurmanji) variety of the Badinan / Duhok region — written in the Arabic script. Keep Kurmanji grammar and vocabulary but use the Arabic-script orthography used in Badini publications.'
    },
    pnb: {
      label: 'Palewani (Southern Kurdish)',
      native: 'کوردیی باشووری',
      instruction:
        'Southern Kurdish (Palewani / Kirmashani / Feyli) written in the Arabic script, as spoken in Kermanshah, Ilam and Lorestan. Use Southern Kurdish grammar and vocabulary (e.g. ھەر، ئەی، دەس، کێش، وەلات).'
    },
    hac: {
      label: 'Hawrami (Gorani)',
      native: 'ھەورامی',
      instruction:
        'Hawrami / Gorani, the language of the Hawraman region, written in the Arabic script. Use Hawrami vocabulary and grammar (e.g. وەش، ھەرمە، چەم، دەس، کەرە).'
    },
    zza: {
      label: 'Zazaki (Dimli)',
      native: 'Zazakî',
      instruction:
        'Zazaki / Dimli written in the Latin alphabet (ç, ê, î, ş, û, ğ). Use Zazaki grammar and vocabulary (e.g. ez, ti, o, kena, ser, name).'
    }
  };

  const DEFAULTS = {
    apiKey: '',
    model: 'openai/gpt-oss-120b',
    dialect: 'ckb',
    effort: 'low',
    // auto   = Groq first, free keyless Google engine if anything fails
    // groq   = Groq only
    // google = free keyless Google engine only (fastest, no key needed)
    engine: 'auto',
    autoTranslate: false,
    translateOnNav: true,
    translateTitle: true,
    // Translate text that is currently hidden (menus, modals, tooltips) plus
    // hover/aria attributes, so nothing pops up in English later.
    translateHidden: true,
    translateAttributes: true,
    // Measured on a 241-segment page: 32/2000/8 lands at ~1.9s, while
    // 14/900/8 takes ~3.0s and 35/2200/4 takes ~2.8s. Fewer, fatter requests
    // plus wide parallelism beats many tiny requests (per-request overhead
    // dominates once connections are warm).
    maxChars: 2000,
    maxItems: 32,
    concurrency: 8,
    maxCharsPerPass: 90000,
    // Domain rules. `allowOnly` flips the extension into "translate these
    // domains only" mode; `excluded` always wins over everything.
    // Each rule in the "Where it translates" card has its own switch, so one
    // can be turned off without losing the list you typed.
    tldOnly: false,
    siteOnly: false,
    blockList: true,
    allowedTlds: '',
    allowed: '',
    excluded: ''
  };

  /* Host rules.
     "youtube.com"  → youtube.com and every subdomain (www., m., music. …)
     ".com"         → every .com site — only when you type the leading dot
     "*.gov.uk"     → star is optional sugar, same as gov.uk
     A bare "com" matches nothing, so a typo can never open the floodgates. */
  function parseHostList(raw) {
    return String(raw || '')
      .split(/[\n,]+/)
      .map((s) =>
        s
          .trim()
          .toLowerCase()
          .replace(/^https?:\/\//, '')
          .replace(/\/.*$/, '')
          .replace(/^\*\./, '')
          .replace(/\.$/, '')
      )
      .filter(Boolean);
  }

  function hostInList(host, raw) {
    const h = String(host || '').toLowerCase();
    if (!h) return false;
    return parseHostList(raw).some((entry) => {
      if (entry.startsWith('.')) return h.endsWith(entry); // .com → any .com site
      if (!entry.includes('.')) return h === entry; // "com" is not a domain; "localhost" is
      return h === entry || h.endsWith('.' + entry); // youtube.com → it + subdomains
    });
  }

  /* TLD rules are a separate list: ".com" / "com" / ".co.uk" → every site under
     that TLD. Kept apart from domain rules so neither can be confused. */
  function parseTldList(raw) {
    return String(raw || '')
      .split(/[\n,]+/)
      .map((s) =>
        s
          .trim()
          .toLowerCase()
          .replace(/^https?:\/\//, '')
          .replace(/\/.*$/, '')
          .replace(/^\*\./, '')
          .replace(/^\.+/, '')
          .replace(/\.$/, '')
      )
      .filter(Boolean);
  }

  // Older builds had a single "allowOnly" switch; carry it over.
  function normalizeSettings(stored) {
    const s = { ...DEFAULTS, ...(stored || {}) };
    if (stored && stored.allowOnly === true && stored.tldOnly === undefined && stored.siteOnly === undefined) {
      s.tldOnly = parseTldList(stored.allowedTlds).length > 0;
      s.siteOnly = parseHostList(stored.allowed).length > 0;
    }
    delete s.allowOnly;
    return s;
  }

  function hostInTldList(host, raw) {
    const h = String(host || '').toLowerCase();
    if (!h) return false;
    return parseTldList(raw).some((tld) => h === tld || h.endsWith('.' + tld));
  }

  // Which language code the free Google engine should use for each dialect.
  // Google only ships Sorani and Kurmanji, so the rarer dialects borrow the
  // closest one it has instead of failing outright.
  const GOOGLE_LANG = {
    ckb: 'ckb',
    kmr: 'kmr',
    'kmr-arab': 'kmr',
    pnb: 'ckb',
    hac: 'ckb',
    zza: 'kmr'
  };

  // Last-resort engine (MyMemory). Sorani only, so Kurmanji falls back to "ku".
  const MYMEMORY_LANG = {
    ckb: 'en|ckb',
    kmr: 'en|ku',
    'kmr-arab': 'en|ckb',
    pnb: 'en|ckb',
    hac: 'en|ckb',
    zza: 'en|ku'
  };

  globalThis.KRD_SHARED = {
    DEFAULTS,
    DIALECTS,
    GOOGLE_LANG,
    MYMEMORY_LANG,
    parseHostList,
    hostInList,
    parseTldList,
    hostInTldList,
    normalizeSettings,
    GROQ_URL: 'https://api.groq.com/openai/v1/chat/completions',
    GOOGLE_URL: 'https://clients5.google.com/translate_a/t',
    MYMEMORY_URL: 'https://api.mymemory.translated.net/get',
    DEFAULT_MODEL: 'openai/gpt-oss-120b'
  };
})();
