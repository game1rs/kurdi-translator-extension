/* Kurdî Translate — service worker: Groq API client + tab orchestration */
importScripts('shared.js');

const { DEFAULTS, DIALECTS, GROQ_URL, DEFAULT_MODEL, GOOGLE_URL, GOOGLE_LANG, MYMEMORY_URL, MYMEMORY_LANG } =
  globalThis.KRD_SHARED;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// If Groq is clearly broken (bad key, dead model, quota gone) stop hammering it
// and let the free engine carry the session until it cools down.
let groqCooldownUntil = 0;
let groqCooldownReason = '';

async function getSettings() {
  const { ktSettings } = await chrome.storage.local.get({ ktSettings: {} });
  return { ...DEFAULTS, ...(ktSettings || {}) };
}

/* ------------------------------------------------------------------ */
/* Prompt                                                              */
/* ------------------------------------------------------------------ */

function buildMessages(items, dialectKey, n) {
  const d = DIALECTS[dialectKey] || DIALECTS.ckb;

  // Kept deliberately short: this prompt rides along on every single request,
  // so extra sentences cost latency and Groq tokens-per-minute on every batch.
  const system =
    `Translate each item into ${d.label} (${d.native}). ${d.instruction} ` +
    'Write natural native UI wording, not literal word-for-word. ' +
    'Keep names, numbers, URLs, code and {placeholders} unchanged. ' +
    `Return only JSON {"t":[...]} with exactly ${n} strings, same order, no commentary.`;

  return [
    { role: 'system', content: system },
    { role: 'user', content: 'Translate: ' + JSON.stringify(items) }
  ];
}

/* ------------------------------------------------------------------ */
/* Response parsing                                                    */
/* ------------------------------------------------------------------ */

function toStrArray(arr) {
  if (!Array.isArray(arr)) return null;
  return arr.map((x) => (typeof x === 'string' ? x : x == null ? '' : String(x)));
}

function parseTranslations(content, n) {
  if (typeof content !== 'string' || !content.trim()) return null;

  const s = content
    .trim()
    .replace(/^```(?:json)?\s*/i, '')
    .replace(/```\s*$/, '')
    .trim();

  const tryParse = (str) => {
    try {
      return JSON.parse(str);
    } catch {
      return undefined;
    }
  };

  let obj = tryParse(s);

  if (obj === undefined) {
    const m = s.match(/\{[\s\S]*\}/);
    if (m) obj = tryParse(m[0]);
  }

  if (Array.isArray(obj)) {
    const a = toStrArray(obj);
    if (a) return a;
  }

  if (obj && typeof obj === 'object') {
    if (Array.isArray(obj.t)) {
      const a = toStrArray(obj.t);
      if (a) return a;
    }
    // Model may have used a different key — take the first string array found.
    const found = Object.values(obj).find((v) => Array.isArray(v));
    const a = toStrArray(found);
    if (a) return a;
  }

  // Bare array somewhere in the text.
  const m2 = s.match(/\[[\s\S]*\]/);
  if (m2) {
    const a = toStrArray(tryParse(m2[0]));
    if (a) return a;
  }

  // Last resort: one translation per line.
  const lines = s
    .split(/\r?\n/)
    .map((l) => l.replace(/^\s*(?:\d+[.):]|[-*])\s*/, '').trim())
    .filter((l) => l.length);
  if (lines.length === n) return lines;

  return null;
}

/* ------------------------------------------------------------------ */
/* Groq call                                                           */
/* ------------------------------------------------------------------ */

async function fetchWithTimeout(url, opts, ms) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), ms);
  try {
    return await fetch(url, { ...opts, signal: ctrl.signal });
  } finally {
    clearTimeout(timer);
  }
}

async function requestOnce(body, apiKey) {
  const res = await fetchWithTimeout(GROQ_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`
    },
    body: JSON.stringify(body)
  }, 20000);
  const text = await res.text();
  let json = null;
  try {
    json = text ? JSON.parse(text) : null;
  } catch {
    json = null;
  }
  return { res, json, text };
}

async function groqTranslate(items, settings, dialectKey) {
  const apiKey = (settings.apiKey || '').trim();
  if (!apiKey) {
    throw new Error('Missing Groq API key — open the extension settings and paste your key (it starts with gsk_).');
  }

  const n = items.length;
  const body = {
    model: settings.model || DEFAULT_MODEL,
    messages: buildMessages(items, dialectKey, n),
    temperature: 0.2,
    // Enough for the batch, small enough that the model can never ramble.
    max_completion_tokens: Math.min(4096, 384 + items.join('').length),
    response_format: { type: 'json_object' },
    include_reasoning: false
  };
  if (settings.effort && settings.effort !== 'none') body.reasoning_effort = settings.effort;

  let attempt = 0;
  let rateHits = 0;

  for (;;) {
    let r;
    try {
      r = await requestOnce(body, apiKey);
    } catch (e) {
      if (attempt < 2) {
        attempt += 1;
        await sleep(400 * attempt);
        continue;
      }
      const reason = e && e.name === 'AbortError' ? 'timed out' : (e && e.message) || String(e);
      throw new Error(`Network error contacting Groq (${reason})`);
    }

    const { res, json, text } = r;

    if (res.ok) {
      const content = json && json.choices && json.choices[0] && json.choices[0].message
        ? json.choices[0].message.content
        : '';
      return content || '';
    }

    // Some models reject the reasoning parameters — retry without them.
    if (res.status === 400 && /reasoning/i.test(text) && ('reasoning_effort' in body || 'include_reasoning' in body)) {
      delete body.reasoning_effort;
      delete body.include_reasoning;
      continue;
    }

    // Rate limited: one quick retry, then park Groq and let the free engine
    // carry the page. Retrying every batch with backoff is what made big pages
    // crawl on the free Groq tier.
    if (res.status === 429) {
      rateHits += 1;
      if (rateHits === 1) {
        await sleep(600 + Math.random() * 300);
        continue;
      }
      groqCooldownUntil = Date.now() + 90 * 1000;
      throw new Error('Groq rate limit — switched to the free engine for a moment.');
    }

    if (res.status >= 500 && attempt < 2) {
      const ra = parseFloat(res.headers.get('retry-after') || '0');
      const wait = ra > 0 ? Math.min(ra * 1000, 4000) : 400 * Math.pow(2, attempt);
      attempt += 1;
      await sleep(wait);
      continue;
    }

    if (res.status === 401 || res.status === 403) {
      throw new Error('Groq rejected the API key (401/403). Check the key in the extension settings.');
    }
    if (res.status === 404) {
      throw new Error(`Model "${body.model}" is not available on your Groq account. Pick another model in settings.`);
    }
    if (res.status === 413) {
      throw new Error('Request too large for Groq — lower "Characters per request" in settings.');
    }

    throw new Error(`Groq API ${res.status}: ${String(text || '').slice(0, 240)}`);
  }
}

/* ------------------------------------------------------------------ */
/* Translate handler                                                   */
/* ------------------------------------------------------------------ */

/* ------------------------------------------------------------------ */
/* Free keyless engines — no API key, no signup, always available      */
/*   1. Google (clients5 "dict-chrome-ex" endpoint, batches q params)  */
/*   2. MyMemory (500-char cap per query, Sorani only)                 */
/* ------------------------------------------------------------------ */

async function getJson(url, attempts = 2) {
  for (let a = 0; a <= attempts; a += 1) {
    try {
      const res = await fetchWithTimeout(url, {
        method: 'GET',
        headers: { Accept: 'application/json' },
        credentials: 'omit'
      }, 12000);

      if (res.status === 429 || res.status >= 500) {
        if (a < attempts) {
          await sleep(300 * (a + 1) + Math.random() * 200);
          continue;
        }
        return null;
      }
      if (!res.ok) return null;

      const txt = await res.text();
      try {
        return JSON.parse(txt);
      } catch {
        return null;
      }
    } catch {
      if (a < attempts) {
        await sleep(300 * (a + 1));
        continue;
      }
      return null;
    }
  }
  return null;
}

/* Google returns [["translated","en"],["translated","en"],...] for N q params,
   and a flat ["translated","en"] shape in some cases. */
function googleRows(data) {
  if (!Array.isArray(data) || !data.length) return null;
  if (Array.isArray(data[0])) {
    return data.map((row) => (Array.isArray(row) ? row[0] : row));
  }
  return [data[0]];
}

function googleUrl(tl, texts) {
  const qs = texts.map((t) => 'q=' + encodeURIComponent(t)).join('&');
  return `${GOOGLE_URL}?client=dict-chrome-ex&sl=auto&tl=${encodeURIComponent(tl)}&${qs}`;
}

async function googleBatch(items, tl) {
  const out = new Array(items.length);
  let i = 0;

  while (i < items.length) {
    // Keep the GET URL comfortably short.
    const group = [];
    let size = 0;
    while (i < items.length) {
      const len = encodeURIComponent(items[i]).length;
      if (group.length && size + len > 4500) break;
      group.push(i);
      size += len + 3;
      i += 1;
    }

    const data = await getJson(googleUrl(tl, group.map((idx) => items[idx])));
    const rows = googleRows(data);

    // Any size mismatch means the mapping is untrustworthy — bail out.
    if (!rows || rows.length !== group.length) return null;

    for (let k = 0; k < group.length; k += 1) {
      const text = rows[k];
      if (typeof text !== 'string' || !text.trim()) return null;
      out[group[k]] = text;
    }
  }

  return out;
}

async function googlePerSegment(items, tl) {
  const out = new Array(items.length);
  let cursor = 0;
  let failures = 0;
  let successes = 0;

  const worker = async () => {
    for (;;) {
      const i = cursor;
      cursor += 1;
      if (i >= items.length) return;
      // If the host is clearly down, stop wasting requests on it.
      if (failures >= 3 && successes === 0) {
        out[i] = items[i];
        continue;
      }

      const data = await getJson(googleUrl(tl, [items[i]]), 1);
      const rows = googleRows(data);
      const text = rows && rows[0];
      if (typeof text === 'string' && text.trim()) {
        out[i] = text;
        successes += 1;
      } else {
        out[i] = items[i];
        failures += 1;
      }
    }
  };

  await Promise.all(Array.from({ length: Math.min(6, items.length) }, worker));
  return successes > 0 ? out : null;
}

/* ---------------------------- MyMemory ---------------------------- */

function splitChunks(text, max = 480) {
  if (text.length <= max) return [text];
  const parts = [];
  let rest = text;
  while (rest.length > max) {
    let cut = rest.lastIndexOf(' ', max);
    if (cut < max * 0.4) cut = max;
    parts.push(rest.slice(0, cut));
    rest = rest.slice(cut).replace(/^\s+/, '');
  }
  if (rest) parts.push(rest);
  return parts;
}

async function myMemoryOne(text, pair) {
  const url = `${MYMEMORY_URL}?q=${encodeURIComponent(text)}&langpair=${encodeURIComponent(pair)}`;
  const data = await getJson(url, 1);
  if (!data || !data.responseData) return null;

  const status = String(data.responseStatus || '');
  if (status && status !== '200') return null;

  const t = data.responseData.translatedText;
  if (typeof t !== 'string' || !t.trim()) return null;
  // MyMemory reports quota/length problems inside the payload, not via HTTP.
  if (/QUERY LENGTH LIMIT|MYMEMORY WARNING|INVALID (LANGUAGE|EMAIL)|TOO MANY REQUESTS/i.test(t)) return null;

  return t;
}

async function myMemoryPerSegment(items, dialectKey) {
  const pair = MYMEMORY_LANG[dialectKey] || 'en|ckb';
  const out = new Array(items.length);
  let cursor = 0;
  let failures = 0;
  let successes = 0;

  const worker = async () => {
    for (;;) {
      const i = cursor;
      cursor += 1;
      if (i >= items.length) return;
      if (failures >= 3 && successes === 0) {
        out[i] = items[i];
        continue;
      }

      const chunks = splitChunks(items[i]);
      const pieces = [];
      let ok = true;

      for (const chunk of chunks) {
        const t = await myMemoryOne(chunk, pair);
        if (t == null) {
          ok = false;
          break;
        }
        pieces.push(t);
      }

      if (ok) {
        out[i] = pieces.join(' ');
        successes += 1;
      } else {
        out[i] = items[i];
        failures += 1;
      }
    }
  };

  await Promise.all(Array.from({ length: Math.min(4, items.length) }, worker));
  return successes > 0 ? out : null;
}

/* ---------------------------- Chain ------------------------------- */

async function freeTranslate(items, dialectKey) {
  const tl = GOOGLE_LANG[dialectKey] || 'ckb';

  const batched = await googleBatch(items, tl);
  if (batched) return { translations: batched, engine: 'google' };

  const perSegment = await googlePerSegment(items, tl);
  if (perSegment) return { translations: perSegment, engine: 'google' };

  const memory = await myMemoryPerSegment(items, dialectKey);
  if (memory) return { translations: memory, engine: 'mymemory' };

  // Everything is down: leave the page untouched rather than half-translated.
  return { translations: items.slice(), engine: 'none' };
}

/* ------------------------------------------------------------------ */
/* Translate handler: Groq first, free engine as a safety net          */
/* ------------------------------------------------------------------ */

async function viaGroq(items, settings, dialectKey) {
  let raw = await groqTranslate(items, settings, dialectKey);
  let arr = parseTranslations(raw, items.length);

  if (!arr) {
    raw = await groqTranslate(items, settings, dialectKey);
    arr = parseTranslations(raw, items.length);
  }

  if (!arr) throw new Error('Unparsable model response');

  if (arr.length < items.length) {
    for (let i = arr.length; i < items.length; i += 1) arr[i] = items[i];
  }
  return arr.slice(0, items.length);
}

function noteGroqFailure(err) {
  const msg = String((err && err.message) || err);
  // Only back off for problems that won't fix themselves in a second.
  if (/401|403|404|rejected the API key|not available on your Groq account|quota|billing|rate limit/i.test(msg)) {
    groqCooldownUntil = Date.now() + 5 * 60 * 1000;
    groqCooldownReason = msg;
  }
}

async function handleTranslate(msg) {
  const settings = await getSettings();
  const items = Array.isArray(msg.items) ? msg.items.filter((x) => typeof x === 'string') : [];
  if (!items.length) return { ok: true, translations: [], engine: 'none' };

  const dialectKey = msg.dialect || settings.dialect;
  const engine = msg.engine || settings.engine || 'auto';
  const hasKey = !!(settings.apiKey || '').trim();
  const groqCooling = Date.now() < groqCooldownUntil;

  // 1. Free engine only.
  if (engine === 'google' || !hasKey) {
    const r = await freeTranslate(items, dialectKey);
    return { ok: true, translations: r.translations, engine: r.engine };
  }

  // 2. Groq only, no safety net.
  if (engine === 'groq') {
    try {
      const arr = await viaGroq(items, settings, dialectKey);
      return { ok: true, translations: arr, engine: 'groq' };
    } catch (e) {
      noteGroqFailure(e);
      return { ok: false, error: String((e && e.message) || e) };
    }
  }

  // 3. auto — Groq, and on any failure quietly finish with the free engine.
  if (!groqCooling) {
    try {
      const arr = await viaGroq(items, settings, dialectKey);
      return { ok: true, translations: arr, engine: 'groq' };
    } catch (e) {
      noteGroqFailure(e);
    }
  }

  const r = await freeTranslate(items, dialectKey);
  return { ok: true, translations: r.translations, engine: r.engine };
}

/* ------------------------------------------------------------------ */
/* Messaging                                                           */
/* ------------------------------------------------------------------ */

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const type = msg && msg.type;

  if (type === 'krd:translate') {
    handleTranslate(msg)
      .then(sendResponse)
      .catch((e) => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true;
  }

  if (type === 'krd:badge') {
    const tabId = sender && sender.tab ? sender.tab.id : null;
    if (tabId != null) {
      try {
        chrome.action.setBadgeBackgroundColor({ tabId, color: '#F55036' });
        chrome.action.setBadgeText({ tabId, text: msg.text || '' });
      } catch {
        /* tab gone */
      }
    }
    sendResponse({ ok: true });
    return false;
  }

  if (type === 'krd:getSettings') {
    getSettings().then((s) => sendResponse({ ok: true, settings: s }));
    return true;
  }

  if (type === 'krd:test') {
    (async () => {
      try {
        const settings = await getSettings();
        const sample = ['Welcome to our website', 'Sign in to continue', 'Settings'];
        const res = await handleTranslate({
          type: 'krd:translate',
          items: sample,
          dialect: settings.dialect,
          engine: msg.engine || settings.engine
        });
        if (!res.ok) throw new Error(res.error || 'Translation failed.');
        sendResponse({
          ok: true,
          sample,
          translations: res.translations,
          engine: res.engine,
          hasKey: !!(settings.apiKey || '').trim()
        });
      } catch (e) {
        sendResponse({ ok: false, error: String((e && e.message) || e) });
      }
    })();
    return true;
  }

  return false;
});

/* ------------------------------------------------------------------ */
/* SPA / history navigation → ask the tab to re-translate              */
/* ------------------------------------------------------------------ */

async function notifyTab(tabId) {
  if (tabId == null) return;
  try {
    await chrome.tabs.sendMessage(tabId, { type: 'krd:urlchange' });
  } catch {
    /* no content script in this tab */
  }
}

chrome.webNavigation.onHistoryStateUpdated.addListener((d) => {
  if (d.frameId === 0) notifyTab(d.tabId);
});

chrome.webNavigation.onReferenceFragmentUpdated.addListener((d) => {
  if (d.frameId === 0) notifyTab(d.tabId);
});

chrome.webNavigation.onCommitted.addListener((d) => {
  if (d.frameId === 0) {
    try {
      chrome.action.setBadgeText({ tabId: d.tabId, text: '' });
    } catch {
      /* ignore */
    }
  }
});

/* ------------------------------------------------------------------ */
/* Keyboard shortcuts                                                  */
/* ------------------------------------------------------------------ */

chrome.commands.onCommand.addListener(async (command, tab) => {
  if (!tab || tab.id == null) return;
  const map = {
    'translate-page': 'krd:translate',
    'toggle-auto': 'krd:toggleAuto',
    'restore-page': 'krd:restore'
  };
  const type = map[command];
  if (!type) return;
  try {
    await chrome.tabs.sendMessage(tab.id, { type });
  } catch {
    /* ignore */
  }
});

/* ------------------------------------------------------------------ */
/* First run → open the settings page so the user can paste the key    */
/* ------------------------------------------------------------------ */

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    chrome.runtime.openOptionsPage().catch(() => {});
  }
});
