/* Kurdî Translate — popup controller */
const SH = globalThis.KRD_SHARED;
const { DEFAULTS, DIALECTS } = SH;

const $ = (id) => document.getElementById(id);
const els = {
  subtitle: $('subtitle'),
  dot: $('dot'),
  warn: $('warn'),
  warnLink: $('warnLink'),
  translateBtn: $('translateBtn'),
  restoreBtn: $('restoreBtn'),
  settingsBtn: $('settingsBtn'),
  keysBtn: $('keysBtn'),
  autoToggle: $('autoToggle'),
  navToggle: $('navToggle'),
  dialectSelect: $('dialectSelect'),
  dialectNative: $('dialectNative'),
  statusLine: $('statusLine'),
  siteHost: $('siteHost'),
  siteToggle: $('siteToggle')
};

let tabId = null;
let tabUrl = '';
let lastState = null;
let settings = { ...DEFAULTS };

/* ------------------------------------------------------------------ */

function fillDialects() {
  els.dialectSelect.innerHTML = '';
  for (const [key, d] of Object.entries(DIALECTS)) {
    const opt = document.createElement('option');
    opt.value = key;
    opt.textContent = d.label;
    els.dialectSelect.appendChild(opt);
  }
}

async function loadSettings() {
  const { ktSettings } = await chrome.storage.local.get({ ktSettings: {} });
  settings = SH.normalizeSettings(ktSettings);
}

async function saveSettings(patch) {
  settings = { ...settings, ...patch };
  await chrome.storage.local.set({ ktSettings: settings });
}

function render() {
  const d = DIALECTS[settings.dialect] || DIALECTS.ckb;
  els.subtitle.textContent = `${settings.model || 'openai/gpt-oss-120b'} · ${d.label}`;
  els.dialectNative.textContent = d.native;
  els.dialectSelect.value = settings.dialect;
  els.autoToggle.checked = !!settings.autoTranslate;
  els.navToggle.checked = !!settings.translateOnNav;
  els.warn.classList.toggle('show', !settings.apiKey && settings.engine === 'groq');
}

function setDot(state) {
  els.dot.className = 'dot';
  if (!state) return;
  if (state.busy) els.dot.classList.add('busy');
  else if (state.auto) els.dot.classList.add('on');
}

/* ------------------------------------------------------------------ */

async function getTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab || null;
}

async function ping() {
  if (tabId == null) return null;
  try {
    const res = await chrome.tabs.sendMessage(tabId, { type: 'krd:ping' });
    return res && res.state ? res.state : null;
  } catch {
    return null;
  }
}

async function ensureContent() {
  if (tabId == null) return false;
  if (await ping()) return true;
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['shared.js', 'content.js']
    });
    await new Promise((r) => setTimeout(r, 200));
    return !!(await ping());
  } catch {
    return false;
  }
}

function describe(state) {
  if (!state) return 'Not available on this page';
  if (state.excluded) return 'Skipped · in your never-translate list';
  if (state.allowed === false) {
    return state.allowEmpty
      ? 'Skipped · your translate-only list is empty'
      : 'Skipped · not in your translate-only list';
  }
  if (state.busy) return 'Translating…';
  if (state.translated > 0) {
    const via = state.engine === 'google' ? 'free engine' : state.engine === 'groq' ? 'Groq' : '';
    return `${state.translated} segments${via ? ' · ' + via : ''}`;
  }
  if (state.engine === 'google') return 'Ready · free engine, no key needed';
  return 'Ready';
}

function renderSiteRow(state) {
  let host = '';
  try {
    host = new URL(tabUrl).hostname;
  } catch {
    host = '';
  }
  els.siteHost.textContent = host;

  // In "only these domains" mode the quick action builds the allow list;
  // otherwise it builds the never-translate list. Same button, opposite list.
  const only = !!settings.siteOnly;
  const list = SH.parseHostList(only ? settings.allowed : settings.excluded);
  const entry = host.replace(/^www\./, '');
  const inList = !!host && (list.includes(entry) || list.includes(host));

  els.siteToggle.dataset.mode = only ? 'allow' : 'block';
  els.siteToggle.dataset.inList = inList ? '1' : '';
  els.siteToggle.textContent = only
    ? inList
      ? 'Remove from translate-only list'
      : 'Add to translate-only list'
    : inList
      ? 'Always translate this site'
      : 'Never translate this site';
}

async function refreshState() {
  const state = await ping();
  lastState = state;
  if (state) {
    setDot(state);
    els.statusLine.textContent = state.error && state.translated === 0 ? state.error : describe(state);
    els.autoToggle.checked = !!state.auto;
    els.translateBtn.disabled = false;
    els.translateBtn.textContent = state.blocked ? 'Translate anyway' : 'Translate this page';
    els.restoreBtn.disabled = state.translated === 0 && !state.busy;
    renderSiteRow(state);
  } else {
    setDot(null);
    els.statusLine.textContent = 'Reload the page to activate';
    els.translateBtn.disabled = true;
    els.restoreBtn.disabled = true;
  }
}

/* ------------------------------------------------------------------ */

els.translateBtn.addEventListener('click', async () => {
  if (!settings.apiKey && settings.engine === 'groq') {
    chrome.runtime.openOptionsPage();
    return;
  }
  const force = !!(lastState && lastState.blocked);
  els.translateBtn.disabled = true;
  els.translateBtn.textContent = 'Translating…';
  const ok = await ensureContent();
  if (ok) {
    try {
      await chrome.tabs.sendMessage(tabId, { type: 'krd:translate', force });
    } catch {
      /* ignore */
    }
  }
  els.translateBtn.textContent = force ? 'Translate anyway' : 'Translate this page';
  els.translateBtn.disabled = false;
  setTimeout(refreshState, 300);
  // Keep polling briefly so the status line settles on the real result.
  let n = 0;
  const t = setInterval(async () => {
    n += 1;
    await refreshState();
    if (n > 20) clearInterval(t);
  }, 700);
});

els.restoreBtn.addEventListener('click', async () => {
  if (tabId == null) return;
  try {
    await chrome.tabs.sendMessage(tabId, { type: 'krd:restore' });
  } catch {
    /* ignore */
  }
  setTimeout(refreshState, 200);
});

els.settingsBtn.addEventListener('click', () => chrome.runtime.openOptionsPage());

els.siteToggle.addEventListener('click', async () => {
  let host = '';
  try {
    host = new URL(tabUrl).hostname;
  } catch {
    return;
  }
  if (!host) return;

  const mode = els.siteToggle.dataset.mode === 'allow' ? 'allow' : 'block';
  const inList = els.siteToggle.dataset.inList === '1';
  // Store "youtube.com" rather than "www.youtube.com" so the entry also covers
  // m.youtube.com and every other subdomain.
  const entry = host.replace(/^www\./, '');
  const key = mode === 'allow' ? 'allowed' : 'excluded';
  const list = SH.parseHostList(settings[key]);
  const next = inList ? list.filter((h) => h !== entry && h !== host) : [...list, entry];

  await saveSettings({ [key]: next.join('\n') });

  if (tabId != null) {
    try {
      await chrome.tabs.sendMessage(tabId, {
        type: 'krd:settings',
        settings: { [key]: settings[key] }
      });

      if (mode === 'allow') {
        // Newly allowed → translate it right away.
        if (!inList) await chrome.tabs.sendMessage(tabId, { type: 'krd:translate' });
      } else if (!inList) {
        // Newly blocked → put the page back to English.
        await chrome.tabs.sendMessage(tabId, { type: 'krd:restore' });
      }
    } catch {
      /* ignore */
    }
  }
  setTimeout(refreshState, 300);
});
els.warnLink.addEventListener('click', (e) => {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
});
els.keysBtn.addEventListener('click', () => {
  chrome.tabs.create({ url: 'chrome://extensions/shortcuts' });
});

els.autoToggle.addEventListener('change', async () => {
  const value = els.autoToggle.checked;
  await saveSettings({ autoTranslate: value });
  if (tabId != null) {
    try {
      await chrome.tabs.sendMessage(tabId, { type: 'krd:setAuto', value });
    } catch {
      /* ignore */
    }
  }
  setTimeout(refreshState, 400);
});

els.navToggle.addEventListener('change', async () => {
  const value = els.navToggle.checked;
  await saveSettings({ translateOnNav: value });
  if (tabId != null) {
    try {
      await chrome.tabs.sendMessage(tabId, { type: 'krd:settings', settings: { translateOnNav: value } });
    } catch {
      /* ignore */
    }
  }
});

els.dialectSelect.addEventListener('change', async () => {
  const value = els.dialectSelect.value;
  await saveSettings({ dialect: value });
  render();
  if (tabId != null) {
    try {
      await chrome.tabs.sendMessage(tabId, { type: 'krd:settings', settings: { dialect: value } });
    } catch {
      /* ignore */
    }
  }
});

/* ------------------------------------------------------------------ */

(async () => {
  fillDialects();
  await loadSettings();
  render();

  const tab = await getTab();
  if (!tab || tab.id == null || !/^https?:/i.test(tab.url || '')) {
    setDot(null);
    els.statusLine.textContent = 'Not available on this page';
    els.translateBtn.disabled = true;
    els.restoreBtn.disabled = true;
    return;
  }
  tabId = tab.id;
  tabUrl = tab.url || '';
  await refreshState();
})();
