/* Kurdî Translate — options page controller */
const SH = globalThis.KRD_SHARED;
const { DEFAULTS, DIALECTS } = SH;

const $ = (id) => document.getElementById(id);

const fields = {
  apiKey: $('apiKey'),
  engine: $('engine'),
  model: $('model'),
  dialect: $('dialect'),
  effort: $('effort'),
  autoTranslate: $('autoTranslate'),
  translateOnNav: $('translateOnNav'),
  translateTitle: $('translateTitle'),
  translateHidden: $('translateHidden'),
  translateAttributes: $('translateAttributes'),
  tldOnly: $('tldOnly'),
  siteOnly: $('siteOnly'),
  blockList: $('blockList'),
  allowedTlds: $('allowedTlds'),
  allowed: $('allowed'),
  maxChars: $('maxChars'),
  maxItems: $('maxItems'),
  concurrency: $('concurrency'),
  maxCharsPerPass: $('maxCharsPerPass'),
  excluded: $('excluded')
};

let settings = { ...DEFAULTS };

function fillDialects() {
  fields.dialect.innerHTML = '';
  for (const [key, d] of Object.entries(DIALECTS)) {
    const opt = document.createElement('option');
    opt.value = key;
    opt.textContent = `${d.label} — ${d.native}`;
    fields.dialect.appendChild(opt);
  }
}

function dim(id, on) {
  const el = $(id);
  if (el) el.style.opacity = on ? '1' : '0.45';
}

function render() {
  fields.apiKey.value = settings.apiKey || '';
  fields.engine.value = settings.engine || DEFAULTS.engine;
  fields.model.value = settings.model || DEFAULTS.model;
  fields.dialect.value = settings.dialect || DEFAULTS.dialect;
  fields.effort.value = settings.effort || DEFAULTS.effort;

  fields.autoTranslate.checked = !!settings.autoTranslate;
  fields.translateOnNav.checked = !!settings.translateOnNav;
  fields.translateTitle.checked = !!settings.translateTitle;
  fields.translateHidden.checked = !!settings.translateHidden;
  fields.translateAttributes.checked = !!settings.translateAttributes;

  fields.tldOnly.checked = !!settings.tldOnly;
  fields.siteOnly.checked = !!settings.siteOnly;
  fields.blockList.checked = !!settings.blockList;
  fields.allowedTlds.value = settings.allowedTlds || '';
  fields.allowed.value = settings.allowed || '';
  fields.excluded.value = settings.excluded || '';

  dim('tldField', settings.tldOnly);
  dim('siteField', settings.siteOnly);
  dim('blockField', settings.blockList);

  fields.maxChars.value = settings.maxChars;
  fields.maxItems.value = settings.maxItems;
  fields.concurrency.value = settings.concurrency;
  fields.maxCharsPerPass.value = settings.maxCharsPerPass;
}

function collect() {
  const num = (v, fallback, min, max) => {
    const n = parseInt(String(v).replace(/[^\d]/g, ''), 10);
    if (!Number.isFinite(n)) return fallback;
    return Math.max(min, Math.min(max, n));
  };

  return {
    apiKey: fields.apiKey.value.trim(),
    engine: fields.engine.value,
    model: fields.model.value.trim() || DEFAULTS.model,
    dialect: fields.dialect.value,
    effort: fields.effort.value,
    autoTranslate: fields.autoTranslate.checked,
    translateOnNav: fields.translateOnNav.checked,
    translateTitle: fields.translateTitle.checked,
    translateHidden: fields.translateHidden.checked,
    translateAttributes: fields.translateAttributes.checked,
    tldOnly: fields.tldOnly.checked,
    siteOnly: fields.siteOnly.checked,
    blockList: fields.blockList.checked,
    allowedTlds: fields.allowedTlds.value,
    allowed: fields.allowed.value,
    excluded: fields.excluded.value,
    maxChars: num(fields.maxChars.value, DEFAULTS.maxChars, 400, 6000),
    maxItems: num(fields.maxItems.value, DEFAULTS.maxItems, 5, 120),
    concurrency: num(fields.concurrency.value, DEFAULTS.concurrency, 1, 8),
    maxCharsPerPass: num(fields.maxCharsPerPass.value, DEFAULTS.maxCharsPerPass, 5000, 400000)
  };
}

function flash(el) {
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 1600);
}

async function save({ quiet = false } = {}) {
  settings = collect();
  await chrome.storage.local.set({ ktSettings: settings });
  render();
  previewMatch();

  if (!quiet) {
    flash($('savedMsg'));
    flash($('savedMsg2'));
  }

  // Push to every open tab so changes apply without a reload.
  try {
    const tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] });
    for (const t of tabs) {
      if (t.id == null) continue;
      chrome.tabs.sendMessage(t.id, { type: 'krd:settings', settings }).catch(() => {});
    }
  } catch {
    /* ignore */
  }
}

/* Live answer to "would this site actually be translated?" */
async function previewMatch() {
  const el = $('matchPreview');
  el.className = 'result';
  el.textContent = '';

  try {
    const tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] });
    if (!tabs.length) return;

    const tab = tabs.find((t) => t.active) || tabs[0];
    const host = new URL(tab.url).hostname;
    const s = collect();

    const byBlock = s.blockList && SH.hostInList(host, s.excluded);
    const failTld = s.tldOnly && !SH.hostInTldList(host, s.allowedTlds);
    const failSite = s.siteOnly && !SH.hostInList(host, s.allowed);

    el.className = 'result ' + (byBlock || failTld || failSite ? 'err' : 'ok');
    el.textContent = byBlock
      ? host + ' — skipped, it is in your never-translate list.'
      : failTld
        ? host + ' — skipped, its ending is not in your TLD list.'
        : failSite
          ? host + ' — skipped, it is not in your site list.'
          : host + ' — will be translated.';
  } catch {
    /* no tabs to preview */
  }
}

/* ------------------------------------------------------------------ */

$('toggleKey').addEventListener('click', () => {
  const isPw = fields.apiKey.type === 'password';
  fields.apiKey.type = isPw ? 'text' : 'password';
  $('toggleKey').textContent = isPw ? 'Hide' : 'Show';
});

$('saveBtn').addEventListener('click', () => save());

$('resetBtn').addEventListener('click', async () => {
  settings = { ...DEFAULTS, apiKey: settings.apiKey };
  await chrome.storage.local.set({ ktSettings: settings });
  render();
  previewMatch();
  flash($('savedMsg2'));
});

for (const el of Object.values(fields)) {
  el.addEventListener('change', () => save({ quiet: true }));
}

$('testBtn').addEventListener('click', async () => {
  const btn = $('testBtn');
  const out = $('testResult');
  out.className = 'result';
  out.textContent = '';

  if (!fields.apiKey.value.trim() && fields.engine.value === 'groq') {
    out.className = 'result err';
    out.textContent = 'Groq-only mode needs an API key. Switch the engine to Auto or paste a key.';
    return;
  }

  btn.disabled = true;
  btn.textContent = 'Testing…';
  await save({ quiet: true });

  try {
    const res = await chrome.runtime.sendMessage({ type: 'krd:test' });
    if (!res || !res.ok) throw new Error((res && res.error) || 'Unknown error');

    const d = DIALECTS[settings.dialect] || DIALECTS.ckb;
    const engineName =
      res.engine === 'groq'
        ? 'Groq · ' + (settings.model || DEFAULTS.model)
        : res.engine === 'mymemory'
          ? 'the backup engine'
          : 'the free built-in engine';

    out.className = 'result ok';
    out.textContent = `Working — translated with ${engineName} into ${d.label}:`;

    res.sample.forEach((src, i) => {
      const line = document.createElement('span');
      line.className = 'seg';
      const em = document.createElement('em');
      em.textContent = src + ' → ';
      line.appendChild(em);
      line.appendChild(document.createTextNode(res.translations[i] || ''));
      out.appendChild(line);
    });
  } catch (e) {
    out.className = 'result err';
    out.textContent = String((e && e.message) || e);
  } finally {
    btn.disabled = false;
    btn.textContent = 'Test connection';
  }
});

/* ------------------------------------------------------------------ */

(async () => {
  fillDialects();
  const { ktSettings } = await chrome.storage.local.get({ ktSettings: {} });
  settings = SH.normalizeSettings(ktSettings);
  render();
  previewMatch();
  if (!settings.apiKey) fields.apiKey.focus();
})();
